Date::DATE_FORMATS[:default] = '%m/%d/%Y'
Time::DATE_FORMATS[:default] = '%m/%d/%Y %I:%M %p'
