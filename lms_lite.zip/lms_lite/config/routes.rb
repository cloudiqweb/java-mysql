Rails.application.routes.draw do
  use_doorkeeper
  devise_for :users
  root to: "pages#account"

  resources :communications
  resources :contents
  resources :gamifications
  resources :groups
  resources :licensed_contents
  resources :learning_experiences do
    member do
      post :add_content
      post :clear_content
      post :delete_content

      post :add_users
      post :clear_users
      post :delete_users

      post :add_groups
      post :clear_groups
      post :delete_groups
    end
  end
  resources :plans
  resources :reports
  resources :users

  scope '/datatables' do
    post '/learning_experiences/:id/addable_users_list' => 'learning_experiences#datatables_addable_users_list', as: :addable_users_list_learning_experience
  end

  scope '/identity/api/v1' do
    post 'token' => 'identity/api#validate_token'

    scope 'credentials' do
      post 'password' => 'identity/api#authenticate'
      post 'token'    => 'identity/api#validate_token'
    end
  end

  namespace :api do
    namespace :v1 do
      defaults format: :json do
        get :me, to: "users#me", as: :me
        resources :user_groups, only: [:index, :create, :update, :show, :destroy]
        resources :sites, only: [:index, :create, :update, :show, :destroy]
        resources :users, except: :index do
          resources :roles, except: [:new, :edit]
        end
      end
    end
  end
end

