require "application_system_test_case"

class ContentsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit contents_url
  #
  #   assert_selector "h1", text: "Content"
  # end
end
