require "application_system_test_case"

class GroupsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit groups_url
  #
  #   assert_selector "h1", text: "Group"
  # end
end
