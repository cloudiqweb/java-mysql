require "application_system_test_case"

class LicensedContentsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit licensed_contents_url
  #
  #   assert_selector "h1", text: "LicensedContent"
  # end
end
