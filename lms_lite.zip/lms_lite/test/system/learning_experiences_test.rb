require "application_system_test_case"

class LearningExperiencesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit learning_experiences_url
  #
  #   assert_selector "h1", text: "LearningExperience"
  # end
end
