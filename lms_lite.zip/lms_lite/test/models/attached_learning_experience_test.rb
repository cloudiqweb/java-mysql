require 'test_helper'

class AttachedLearningExperienceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
