require 'test_helper'

class LearningExperiencesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @learning_experience = learning_experiences(:one)
  end

  test "should get index" do
    get learning_experiences_url
    assert_response :success
  end

  test "should get new" do
    get new_learning_experience_url
    assert_response :success
  end

  test "should create learning_experience" do
    assert_difference('LearningExperience.count') do
      post learning_experiences_url, params: { learning_experience: { access_expires_at: @learning_experience.access_expires_at, active: @learning_experience.active, description: @learning_experience.description, end_at: @learning_experience.end_at, experience_type: @learning_experience.experience_type, force_linear: @learning_experience.force_linear, offers_completion_certificate: @learning_experience.offers_completion_certificate, ratable: @learning_experience.ratable, mandatory: @learning_experience.mandatory, start_at: @learning_experience.start_at, title: @learning_experience.title } }
    end

    assert_redirected_to learning_experience_url(LearningExperience.last)
  end

  test "should show learning_experience" do
    get learning_experience_url(@learning_experience)
    assert_response :success
  end

  test "should get edit" do
    get edit_learning_experience_url(@learning_experience)
    assert_response :success
  end

  test "should update learning_experience" do
    patch learning_experience_url(@learning_experience), params: { learning_experience: { access_expires_at: @learning_experience.access_expires_at, active: @learning_experience.active, description: @learning_experience.description, end_at: @learning_experience.end_at, experience_type: @learning_experience.experience_type, force_linear: @learning_experience.force_linear, offers_completion_certificate: @learning_experience.offers_completion_certificate, ratable: @learning_experience.ratable, mandatory: @learning_experience.mandatory, start_at: @learning_experience.start_at, title: @learning_experience.title } }
    assert_redirected_to learning_experience_url(@learning_experience)
  end

  test "should destroy learning_experience" do
    assert_difference('LearningExperience.count', -1) do
      delete learning_experience_url(@learning_experience)
    end

    assert_redirected_to learning_experiences_url
  end
end
