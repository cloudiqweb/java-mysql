require "rails_helper"

RSpec.describe LicensedContentsController, type: :routing do
  describe "routing" do

    it "routes to #index" do
      expect(:get => "/licensed_contents").to route_to("licensed_contents#index")
    end

    it "routes to #new" do
      expect(:get => "/licensed_contents/new").to route_to("licensed_contents#new")
    end

    it "routes to #show" do
      expect(:get => "/licensed_contents/1").to route_to("licensed_contents#show", :id => "1")
    end

    it "routes to #edit" do
      expect(:get => "/licensed_contents/1/edit").to route_to("licensed_contents#edit", :id => "1")
    end

    it "routes to #create" do
      expect(:post => "/licensed_contents").to route_to("licensed_contents#create")
    end

    it "routes to #update via PUT" do
      expect(:put => "/licensed_contents/1").to route_to("licensed_contents#update", :id => "1")
    end

    it "routes to #update via PATCH" do
      expect(:patch => "/licensed_contents/1").to route_to("licensed_contents#update", :id => "1")
    end

    it "routes to #destroy" do
      expect(:delete => "/licensed_contents/1").to route_to("licensed_contents#destroy", :id => "1")
    end

  end
end
