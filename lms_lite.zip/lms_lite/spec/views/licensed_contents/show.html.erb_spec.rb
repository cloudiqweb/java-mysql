require 'rails_helper'

RSpec.describe "licensed_contents/show", type: :view do
  let!(:site) { FactoryBot.create(:site) }
  let!(:user) { FactoryBot.create(:user, sites: [site]) }
  let!(:content) { FactoryBot.create(:content) }

  before(:each) do
    @licensed_content = assign(:licensed_content, LicensedContent.create!(
      content: content,
      site: site
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(//)
  end
end
