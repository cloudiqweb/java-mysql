require 'rails_helper'

RSpec.describe "licensed_contents/edit", type: :view do
  let!(:site) { FactoryBot.create(:site) }
  let!(:user) { FactoryBot.create(:user, sites: [site]) }
  let!(:content) { FactoryBot.create(:content) }

  before(:each) do
    @licensed_content = assign(:licensed_content, LicensedContent.create!(
      content: content,
      site: site,
      inactive_at: 1.year.from_now
    ))
  end

  it "renders the edit licensed_content form" do
    render

    assert_select "form[action=?][method=?]", licensed_content_path(@licensed_content), "post" do
      assert_select "input[name=?]", "licensed_content[content_id]"
    end
  end
end
