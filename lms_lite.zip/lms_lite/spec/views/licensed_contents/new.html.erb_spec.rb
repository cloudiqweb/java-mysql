require 'rails_helper'

RSpec.describe "licensed_contents/new", type: :view do
  before(:each) do
    assign(:licensed_content, LicensedContent.new(
      :content => nil
    ))
  end

  it "renders new licensed_content form" do
    render

    assert_select "form[action=?][method=?]", licensed_contents_path, "post" do
      assert_select "input[name=?]", "licensed_content[content_id]"
    end
  end
end
