require 'rails_helper'

RSpec.describe "licensed_contents/index", type: :view do
  let!(:site) { FactoryBot.create(:site) }
  let!(:user) { FactoryBot.create(:user, sites: [site]) }
  let!(:contents) { FactoryBot.create_list(:content, 2) }

  before(:each) do
    assign(:licensed_contents, [
      LicensedContent.create!(
        content: contents.first,
        site: site,
        inactive_at: 1.year.from_now
      ),
      LicensedContent.create!(
        content: contents.last,
        site: site,
        inactive_at: 1.year.from_now
      )
    ])
  end

  it "renders a list of licensed_contents" do
    render
    assert_select "tr>td", :text => contents.first.to_s
    assert_select "tr>td", :text => contents.last.to_s
  end
end
