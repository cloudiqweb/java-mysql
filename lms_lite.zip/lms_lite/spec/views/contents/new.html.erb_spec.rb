require 'rails_helper'

RSpec.describe "contents/new", type: :view do
  before(:each) do
    assign(:content, Content.new(
      :title => "MyString",
      :content_type => 1,
      :description => "MyText"
    ))
  end

  it "renders new content form" do
    render

    assert_select "form[action=?][method=?]", contents_path, "post" do

      assert_select "input[name=?]", "content[title]"

      # TODO: Test fancy selects
      # assert_select "input[name=?]", "content[content_type]"

      assert_select "textarea[name=?]", "content[description]"
    end
  end
end
