require 'rails_helper'

RSpec.describe "contents/edit", type: :view do
  before(:each) do
    @content = assign(:content, Content.create!(
      :title => "MyString",
      :content_type => 1,
      :description => "MyText"
    ))
  end

  it "renders the edit content form" do
    render

    assert_select "form[action=?][method=?]", content_path(@content), "post" do

      assert_select "input[name=?]", "content[title]"

      # TODO: Test fancy selects
      # assert_select "input[name=?]", "content[content_type]"

      assert_select "textarea[name=?]", "content[description]"
    end
  end
end
