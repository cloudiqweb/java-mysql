FactoryBot.define do
  factory :site_relationship do
    name Faker::Company.name
    description Faker::RickAndMorty.location
  end
end

