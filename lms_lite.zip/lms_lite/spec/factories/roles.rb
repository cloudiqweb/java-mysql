FactoryBot.define do
  factory :role do
    name { %w( user subadmin admin superadmin ).sample }
    description Faker::RickAndMorty.location
  end 
end 

