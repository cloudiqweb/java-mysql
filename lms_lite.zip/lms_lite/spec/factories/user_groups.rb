FactoryBot.define do
  factory :user_group do
    name Faker::Company.buzzword
    site nil
  end
end
