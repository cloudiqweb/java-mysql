require 'faker'

FactoryBot.define do
  factory :user do
    sequence :username do |n|
      Faker::Internet.user_name + n.to_s
    end
    given_name { Faker::Name.first_name }
    family_name { Faker::Name.last_name }
    email { "#{SecureRandom.uuid.delete('-')}@test.mediapro.com" }
    password "password"
    sites { [FactoryBot.create(:site)] }
    selected_site_uuid { sites.first&.site_uuid }
  end
end
