FactoryBot.define do
  factory :action do
    sequence(:name) { |n| "action_#{n}" }
    description Faker::RickAndMorty.location
  end
end

