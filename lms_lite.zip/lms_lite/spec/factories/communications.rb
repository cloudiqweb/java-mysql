FactoryBot.define do
  factory :communication do
    user nil
    subject "MyString"
    message "MyText"
  end
end
