require 'faker'

FactoryBot.define do
  factory :content do
    title { Faker::Commerce.product_name }
    content_type 1
    description { Faker::Lorem.paragraph }
  end
end
