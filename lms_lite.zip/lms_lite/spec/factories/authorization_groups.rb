FactoryBot.define do
  factory :authorization_group do
    site
  end
end

