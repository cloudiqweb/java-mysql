require 'faker'

FactoryBot.define do
  factory :learning_experience do
    title { Faker::Company.name }
    description { Faker::Lorem.paragraph }
    experience_type 'Course'
    force_linear false
    start_at nil
    end_at nil
    access_expires_at nil
    ratable true
    offers_completion_certificate true
    mandatory false
    site
  end
end
