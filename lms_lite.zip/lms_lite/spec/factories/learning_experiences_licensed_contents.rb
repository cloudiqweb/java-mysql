FactoryBot.define do
  factory :learning_experiences_licensed_content do
    learning_experience nil
    licensed_content nil
    order 1
  end
end
