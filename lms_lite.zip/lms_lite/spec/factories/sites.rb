FactoryBot.define do
  factory :site do
    name { Faker::Company.name }
    site_uuid { SecureRandom.uuid }
  end
end

