FactoryBot.define do
  factory :licensed_content do
    content
    inactive_at 1.year.from_now
    deleted_at nil
    site
  end
end
