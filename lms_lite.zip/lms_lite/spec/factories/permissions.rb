FactoryBot.define do
  factory :permission do
    action
    classification Faker::RickAndMorty.character
  end
end

