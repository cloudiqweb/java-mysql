FactoryBot.define do
  factory :site_association do
    site
  end
end

