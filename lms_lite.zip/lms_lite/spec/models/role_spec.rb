require 'rails_helper'

RSpec.describe Role, type: :model do
  context "relationships" do
    it "should present its users" do
      user = FactoryBot.create(:user)
      expect(FactoryBot.create(:role, users: [user]).users).to eq [user]
    end

    # todo: not defined yet
    # it "should present its authorization groups" do
    #   FactoryBot.create_list(:authorization_group, 3)
    #   authorization_group = FactoryBot.create(:authorization_group)
    #   expect(
    #     FactoryBot.create(:role, authorization_groups: [authorization_group]).authorization_groups
    #   ).to eq [authorization_group]
    # end
  end
end

