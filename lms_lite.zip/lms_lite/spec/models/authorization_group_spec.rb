require 'rails_helper'

RSpec.describe AuthorizationGroup, type: :model do
  context "relationships" do
    it "should present its roles" do
      FactoryBot.create_list(:role, 3)
      role = FactoryBot.create(:role)
      expect(
        FactoryBot.create(:authorization_group, roles: [role]).roles
      ).to eq [role]
    end

    it "should present its site" do
      site = FactoryBot.create(:site)
      expect(FactoryBot.create(:authorization_group, site: site).site).to eq  site
    end

    it "should present its users" do
      FactoryBot.create_list(:user, 3)
      user = FactoryBot.create(:user)
      expect(
        FactoryBot.create(:authorization_group, users: [user]).users
      ).to eq [user]
    end
  end
end

