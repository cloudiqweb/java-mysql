require 'rails_helper'

RSpec.describe Permission, type: :model do
  context "relationships" do
    it "should present its action" do
      action = FactoryBot.create(:action)
      expect(FactoryBot.create(:permission, action: action).action).to eq action
    end

    it "should present its roles" do
      FactoryBot.create_list(:role, 3)
      role = FactoryBot.create(:role)
      expect(FactoryBot.create(:permission, roles: [role]).roles).to eq [role]
    end

    it "should remove its action when destroyed" do
      action = FactoryBot.create(:action)
      permission = FactoryBot.create(:permission, action: action)
      expect{ permission.destroy}.to_not change{ Action.count }
    end
  end
end

