require 'rails_helper'

RSpec.describe Site, type: :model do
  context 'validations' do
    it { should validate_presence_of(:name) }

    it 'should be unique case insensitive' do
      FactoryBot.create(:site, name: "test")
      site_dupe = FactoryBot.build(:site, name: "TEST")
      expect(site_dupe.save).to be false
      expect(site_dupe.errors).not_to be_empty
      expect(site_dupe.errors.full_messages).to include('Name has already been taken')
    end
  end

  context "relationships" do
    it "should present its authorization groups" do
      site = FactoryBot.create(:site)
      authorization_group = FactoryBot.create(:authorization_group, site: site)
      expect(site.authorization_groups).to eq [authorization_group]
    end

    it "cannot be deleted if authorization groups are assigned to it" do
      site = FactoryBot.create(:site)
      auth_group = FactoryBot.create(:authorization_group, site: site)
      expect{ site.destroy }.to_not change{ Site.count }
      auth_group.destroy
      site.reload
      expect{ site.destroy }.to change{ Site.count }.by(-1)
    end

    context "self-referrential relationships" do
      let!(:related_site) { FactoryBot.create(:site) }
      let!(:child_site) { FactoryBot.create(:site, related_sites: [related_site]) }

      it "presents its site associations" do
        expect(child_site.site_associations).to eq [SiteAssociation.first]
      end

      it "presents all sites where it is a primary" do
        expect(child_site.sites).to eq [child_site]
      end

      it "presents its related sites" do
        expect(child_site.related_sites).to eq [related_site]
      end

      it "should destroy its site associations when destroyed" do
        expect{ child_site.destroy }.to change{ SiteAssociation.count }.by(-1)
      end
    end

    it "should present its users" do
      FactoryBot.create_list(:user, 3)
      user = FactoryBot.create(:user)
      expect(FactoryBot.create(:site, users: [user]).users).to eq [user]
    end
  end

  it "should unlink users after it is deleted" do
    site = FactoryBot.create(:site)
    site = FactoryBot.create(:site)
    Site.current_site = site
    user = FactoryBot.create(:user, sites: [site], selected_site_uuid: site.site_uuid)
    site.destroy
    expect(user.reload.selected_site_uuid).to be_nil
  end

  it 'should be soft deleted' do
    site_one = FactoryBot.create(:site)
    FactoryBot.create(:site)
    expect(Site.count).to eq 2
    site_one.destroy!
    expect(Site.count).to eq 1
    expect(Site.with_deleted.count).to eq 2
  end
end
