require 'rails_helper'

RSpec.describe Communication, type: :model do
  let!(:site) { FactoryBot.create(:site) }
  let!(:group) { FactoryBot.create(:group, site: site) }
  let!(:user) { FactoryBot.create(:user, sites: [site]) }
  let!(:user2) { FactoryBot.create(:user, sites: [site]) }

  before(:each) do
    Site.current_site = site
  end

  context "#for_user" do
    it "lists communications sent to a user" do
      communication = Communication.create(
        site: site,
        user: user,
        subject: 'test subject',
        message: 'test message'
      )
      communication.users << user2

      expect(Communication.for_user(user2)).to include(communication)
    end

    it "lists communications sent to a user's group" do
      group.users << user2
      communication = Communication.create(
        site: site,
        user: user,
        subject: 'test subject',
        message: 'test message'
      )
      communication.groups << group

      expect(Communication.for_user(user2)).to include(communication)
    end
  end
end
