require 'rails_helper'

RSpec.describe SiteAssociation, type: :model do
  context "relationships" do
    it "presents its site relationship" do
      site_relationship = FactoryBot.create(:site_relationship)
      site_association = FactoryBot.create(
        :site_association, site_relationship: site_relationship
      )
      expect(site_association.site_relationship).to eq site_relationship
    end

    it "does not require a site relationship" do
      expect(FactoryBot.build(:site_association, site_relationship: nil)).to be_valid
    end

    it "does not require a related site" do
      expect(FactoryBot.build(:site_association, related_site: nil)).to be_valid
    end

    it "presents its related site" do
      site = FactoryBot.create(:site)
      related_site = FactoryBot.create(:site)
      expect(
        FactoryBot.build(
          :site_association, site: site, related_site: related_site
        ).related_site
      ).to eq related_site
    end

    it "presents its site" do
      site = FactoryBot.create(:site)
      related_site = FactoryBot.create(:site)
      expect(
        FactoryBot.build(
          :site_association, site: site, related_site: related_site
        ).site
      ).to eq site
    end
  end
end

