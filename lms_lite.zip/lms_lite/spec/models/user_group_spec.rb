require "rails_helper"

RSpec.describe UserGroup, type: :model do
  let!(:site) { FactoryBot.create(:site) }

  context "validations" do
    it { should validate_presence_of(:name) }
    it { should validate_length_of(:name).is_at_least(3) }

    it "should have a unique name for each site" do
      name = "TestGroup"
      FactoryBot.create(:user_group, site: site, name: name)
      group = FactoryBot.build(:user_group, site: site, name: name)
      expect(group).to_not be_valid
      expect(error_list(group)).to include "Name has already been taken"
    end
  end

  context "relationships" do
    let(:group) { FactoryBot.create(:user_group, site: site) }

    it "should present its site" do
      expect(group.site).to eq site
    end

    it "should present its users" do
      user = FactoryBot.create(:user, sites: [site])
      group.users << user
      expect(group.users).to eq [user]
    end
  end

  it "should not destroy its users when deleted" do
    user_group = FactoryBot.create(:user_group, site: site)
    user = FactoryBot.create(:user, sites: [site])
    user_group.users << user
    expect(user_group.reload.users.count).to eq 1
    user_group.destroy
    expect(user.reload.user_groups.count).to eq 0
  end

  it "should be soft deleted" do
    group = FactoryBot.create(:user_group, site: site, name: "First")
    FactoryBot.create(:user_group, site: site, name: "Second")
    expect(UserGroup.count).to eq 2
    group.destroy!
    expect(UserGroup.count).to eq 1
    expect(UserGroup.with_deleted.count).to eq 2
  end
end

