require 'rails_helper'

RSpec.describe Action, type: :model do
  context "relationships" do
    it "should present its permissions" do
      FactoryBot.create_list(:permission, 3)
      permission = FactoryBot.create(:permission)
      action = FactoryBot.create(:action, permissions: [permission])
      expect(action.permissions).to eq [permission]
    end

    it "cannot be deleted if permissions are assigned to it" do
      permission = FactoryBot.create(:permission)
      action = FactoryBot.create(:action, permissions: [permission])
      expect{ action.destroy }.to_not change{ Action.count }
      permission.destroy
      action.reload
      expect{ action.destroy }.to change{ Action.count }.by(-1)
    end
  end
end

