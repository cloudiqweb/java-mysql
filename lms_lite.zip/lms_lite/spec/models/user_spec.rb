require 'rails_helper'

RSpec.describe User, type: :model do
  context "relationships" do
    it "should present its authorization groups" do
      FactoryBot.create_list(:authorization_group, 3)
      authorization_group = FactoryBot.create(:authorization_group)
      expect(
        FactoryBot.create(
          :user, authorization_groups: [authorization_group]
        ).authorization_groups
      ).to eq [authorization_group]
    end

    it "should present its roles" do
      FactoryBot.create_list(:role, 3)
      role = FactoryBot.create(:role)
      expect(FactoryBot.create(:user, roles: [role]).roles).to eq [role]
    end

    it "should present its sites" do
      FactoryBot.create_list(:site, 3)
      site = FactoryBot.create(:site)
      expect(FactoryBot.create(:user, sites: [site]).sites).to eq [site]
    end

    it "should present its user groups" do
      site = FactoryBot.create(:site)
      user = FactoryBot.create(:user, sites: [site])
      group = FactoryBot.create(:user_group, users: [user])
      expect(user.user_groups).to eq [group]
    end

    it "should state if it has a role" do
      role = FactoryBot.create(:role)
      user = FactoryBot.create(:user, roles: [role])
      expect(user.has_role?( role)).to be true
    end

    it "should list its roles" do
      role = FactoryBot.create(:role)
      user = FactoryBot.create(:user, roles: [role])
      expect(user.roles_title).to eq role.name
    end
  end

  context "validations" do
    it "requires an email address if no username is present" do
      user = FactoryBot.build(:user, email: nil, username: nil)
      expect(user).to_not be_valid
      expect(error_list(user)).to include "Email or Username must be present"
      expect(FactoryBot.build(:user, email: "egon@gbhq.com", username: nil)).to be_valid
    end

    it "requires a username if no email address is present" do
      user = FactoryBot.build(:user, email: nil, username: nil)
      expect(user).to_not be_valid
      expect(error_list(user)).to include "Email or Username must be present"
      expect(FactoryBot.build(:user, email: nil, username: "egon.s")).to be_valid
    end

    it "requires a unique email address" do
      email = "egon@gbhq.com"
      FactoryBot.create(:user, email: email)
      user = FactoryBot.build(:user, email: email)
      expect(user).to_not be_valid
      expect(
        user.errors.full_messages.join(", ")
      ).to include "Email has already been taken"
    end

    context "usernames" do
      let(:username) { "egon.s" }

      it "allows multiple blank usernames" do
        FactoryBot.create(:user, username: nil)
        user = FactoryBot.build(:user, username: nil)
        expect(user).to be_valid
      end

      it "requires a username without special characters" do
        bad_username = FactoryBot.build(:user, username: "foo#bar")
        expect(bad_username).to_not be_valid
        expect(
          error_list(bad_username)
        ).to include "Username only allows letters, numbers, underscores, periods, and @."
        expect(FactoryBot.build(:user, username: "egon.s")).to be_valid
        expect(FactoryBot.build(:user, username: "egon@gbhq.com")).to be_valid
      end

      it "should be case insensitive" do
        site = FactoryBot.create(:site)
        Site.current_site = site
        user = FactoryBot.create(:user, username: "Egon.S", sites: [site])
        expect(site.users.where(username: 'egon.s').first).to eq user
        # expect(User.where(username: "egon.s", sites: {site: site}).first).to eq user
        expect(FactoryBot.build(:user, username: "egon.S", sites: [site])).to_not be_valid
      end
    end
  end

  context "helpers" do
    describe ".site_uuid" do
      it "returns the selected site UUID if it exists" do
        user = FactoryBot.create(:user, selected_site_uuid: "123")
        expect(user.site_uuid).to eq "123"
      end

      it "returns the first assigned site's UUID if the selected UUID doesn't exist" do
        site = FactoryBot.create(:site)
        user = FactoryBot.create(:user, sites: [site], selected_site_uuid: nil)
        expect(user.site_uuid).to eq site.site_uuid
      end

      it "returns nil if there are no assigned sites and no selected site UUID" do
        user = FactoryBot.create(:user, sites: [])
        expect(user.site_uuid).to be_nil
      end
    end
  end
end

