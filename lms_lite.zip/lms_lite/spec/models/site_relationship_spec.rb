require 'rails_helper'

RSpec.describe SiteRelationship, type: :model do
  context "relationships" do
    it "presents its site_association" do
      site_relationship = FactoryBot.create(:site_relationship)
      association = FactoryBot.create(
        :site_association, site_relationship: site_relationship
      )
      expect(site_relationship.site_association).to eq association
    end
  end
end

