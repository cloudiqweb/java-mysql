require "rails_helper"
require "rspec_api_documentation/dsl"

resource "Users" do
  let(:application) { create_application }
  let(:site) { FactoryBot.create(:site) }
  let(:user) { FactoryBot.create(:user, sites: [site]) }
  let!(:token) { create_token(application.id, user.id).token }

  let(:site_ids) { [site.id] }
  let(:password) { "password" }
  let(:username) { Faker::Internet.user_name + SecureRandom.uuid.delete('-') }
  let(:email) { "#{SecureRandom.uuid.delete('-')}@apitest.mediapro.com" }
  let(:given_name) { Faker::Name.first_name }
  let(:family_name) { Faker::Name.last_name }
  let(:middle_name) { Faker::Name.first_name }
  let(:department) { Faker::Team.creature }
  let(:comments) { Faker::Lorem.sentence }

  # Show 
  get "/api/v1/users/:id" do
    with_options required: true do 
      parameter :id, "User ID"
      parameter :access_token, "Access token"
    end

    example "Get a User with ID." do
      explanation "Returns User with ID as JSON"
      
      do_request(id: user.id, access_token: token)
      expect(response_body).not_to be_empty
      expect(JSON.parse(response_body)['id']).to eq(user.id)
      expect(status).to be 200
    end
  end

  # Create
  post "/api/v1/users" do

    with_options required: true do
      parameter :access_token, "Access token"
      parameter :site_ids, "Site ID's"
      parameter :password
    end

    parameter :username, "Username"
    parameter :email, "E-mail"
    parameter :given_name, "Given Name (first name)"
    parameter :family_name, "Family Name (last name)"
    parameter :middle_name, "Middle Name"
    parameter :department, "Department name"
    parameter :comments, "Comments"

    example "Create a user." do
      explanation "Creates a new User. NOTE: A user without an email or username is invalid! Username will default to email if only email is given."
      do_request(access_token: token)
      expect(status).to be 201
    end
  end

  # Update
  put "/api/v1/users/:id" do
    with_options required: true do
      parameter :id, "User ID"
      parameter :access_token, "Access token"
    end

    parameter :site_ids, "Site ID's"
    parameter :username, "Username"
    parameter :email, "E-mail"
    parameter :password
    parameter :given_name, "Given Name (first name)"
    parameter :family_name, "Family Name (last name)"
    parameter :middle_name, "Middle Name"
    parameter :department, "Department name"
    parameter :comments, "Comments"

    example "Update a User with ID." do
      do_request(id: user.id, access_token: token)
      expect(status).to be 204
    end
  end

  # Destroy
  delete "/api/v1/users/:id" do

    with_options required: true do 
      parameter :id, "User ID"
      parameter :access_token, "Access token"
    end

    example "Delete a User with an ID." do
      explanation "Soft deletes a User with the given ID."
      
      do_request(id: user.id, access_token: token)
      expect(response_body).to be_empty
      expect(status).to be 204
    end
  end
end
