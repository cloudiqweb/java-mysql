require "rails_helper"
require "rspec_api_documentation/dsl"

resource "User Groups" do
  explanation "Allows users to be placed in multiple arbitrary groups. "\
    "Returns a 404 when record is not found"

  let(:application) { create_application }
  let(:site) { FactoryBot.create(:site) }
  let!(:user_group) { FactoryBot.create(:user_group, site: site) }
  let(:user) { FactoryBot.create(:user, sites: [site]) }
  let(:token) { create_token(application.id, user.id).token }

  # Show all
  get "/api/v1/user_groups" do
    with_options required: true do
      parameter :access_token, "Access Token"
    end

    example "Getting all user groups" do
      explanation "Returns all existing user groups"

      do_request(access_token: token)
      expect(status).to eq 200
    end
  end

  # Create
  post "/api/v1/user_groups" do
    with_options required: true do
      parameter :access_token, "Access Token"
      parameter :name, "User Group Name. Minimum length is 3."
    end

    example "Creating a new user group" do
      explanation "Creates a new User Group"

      do_request(access_token: token, name: "Test User Group")
      expect(status).to eq 201
    end

    example "Creating a new user group with bad parameters" do
      explanation "Returns a 422 with an error message"

      do_request(access_token: token, name: "")
      expect(status).to eq 422
    end
  end

  ## Read
  get "/api/v1/user_groups/:id" do
    with_options required: true do
      parameter :access_token, "Access Token"
      parameter :id, "User Group ID"
    end

    example "Getting a user group" do
      explanation "Gets a User Group with given ID"

      do_request(access_token: token, id: user_group.id)
      expect(status).to eq 200
    end
  end

  # Update
  put "/api/v1/user_groups/:id" do
    with_options required: true do
      parameter :access_token, "Access Token"
      parameter :id, "User Group ID"
      parameter :name, "User Group Name. Minimum length is 3."
    end

    example "Updating a user group" do
      explanation "Updates a User Group with given ID"

      do_request(access_token: token, id: user_group.id, name: "First Ghostbusters")
      expect(status).to eq 204
    end

    example "Updating a user group with bad parameters" do
      explanation "Returns 422 with an error message"

      do_request(access_token: token, id: user_group.id, name: "GB")
      expect(status).to eq 422
    end
  end

  # Delete
  delete "/api/v1/user_groups/:id" do
    with_options required: true do
      parameter :access_token, "Access Token"
      parameter :id, "User Group ID"
    end

    example "Deleting a user group" do
      explanation "Deletes a User Group with given ID."

      do_request(access_token: token, id: user_group.id)
      expect(status).to eq 204
    end
  end
end

