require 'rails_helper'
require 'rspec_api_documentation/dsl'

resource 'Sites' do
  explanation 'Equivalent to tenant, a top-level entity for users and learning experiences. '\
    'Returns a 404 when record is not found'

  let(:application) { create_application }
  let(:site) { FactoryBot.create(:site) }
  let!(:another_site) { FactoryBot.create(:site) }
  let(:user) { FactoryBot.create(:user, sites: [site]) }
  let(:token) { create_token(application.id, user.id).token }

  # Show all
  get '/api/v1/sites' do
    with_options required: true do
      parameter :access_token, 'Access Token'
    end

    example 'Getting all sites' do
      explanation 'Returns all existing sites'

      do_request(access_token: token)
      expect(status).to eq 200
    end
  end

  # Create
  post '/api/v1/sites' do
    with_options required: true do
      parameter :access_token, 'Access Token'
      parameter :name, 'Site Name. Required. No duplicate names (case insensitive).'
    end

    example 'Creating a new site' do
      explanation 'Creates a new Site'

      do_request(access_token: token, name: 'Test Site')
      expect(status).to eq 201
    end

    example 'Creating a new site with bad parameters' do
      explanation 'Returns a 422 with an error message'

      do_request(access_token: token, name: site.name)
      expect(status).to eq 422
    end
  end

  # Read
  get '/api/v1/sites/:id' do
    with_options required: true do
      parameter :access_token, 'Access Token'
      parameter :id, 'Site ID'
    end

    example 'Getting a site' do
      explanation 'Gets a Site with given ID'

      do_request(access_token: token, id: site.id)
      expect(status).to eq 200
    end
  end

  # Update
  put '/api/v1/sites/:id' do
    with_options required: true do
      parameter :access_token, 'Access Token'
      parameter :id, 'Site ID'
      parameter :name, 'Site Name. Required. No duplicate names (case insensitive).'
    end

    example 'Updating a site' do
      explanation 'Updates a Site with given ID'

      do_request(access_token: token, id: site.id, name: 'foobar')
      expect(status).to eq 204
    end

    example 'Updating a site with bad parameters' do
      explanation 'Returns 422 with an error message'

      do_request(access_token: token, id: site.id, name: another_site.name)
      expect(status).to eq 422
    end
  end

  # Delete
  delete '/api/v1/sites/:id' do
    with_options required: true do
      parameter :access_token, 'Access Token'
      parameter :id, 'Site ID'
    end

    example 'Deleting a site' do
      explanation 'Deletes a Site with given ID.'

      do_request(access_token: token, id: site.id)
      expect(status).to eq 204
    end
  end
end