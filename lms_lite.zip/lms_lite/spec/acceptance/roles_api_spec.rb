require 'rails_helper'
require 'rspec_api_documentation/dsl'

resource 'Roles' do
  explanation 'Defines bundle of permissions for a user.'
  let(:application) { create_application }
  let(:site) { FactoryBot.create(:site) }
  let(:role) { Role.create(name: "mp admin") }
  let(:new_role) { Role.create(name: "learner") }
  let(:user) { FactoryBot.create(:user, sites: [site], roles: [role] ) }
  let!(:token) { create_token(application.id, user.id) }

  # Show all
  get '/api/v1/users/:user_id/roles' do
    with_options required: true do
      parameter :access_token, 'Access Token'
      parameter :user_id, 'User ID'
    end

    example 'Getting all roles on a user as a title string' do
      explanation 'Returns all existing roles for this user'

      do_request(access_token: token.token, user_id: user.id)
      expect(status).to eq 200
    end
  end

  # user has a role roles
  get '/api/v1/users/:user_id/roles/:id' do
    with_options required: true do
      parameter :access_token, 'Access Token'
      parameter :user_id, 'User ID'
      parameter :id, 'Role ID'
    end
    example 'Check if a user has a role' do
      explanation 'Returns boolean stating if user has the role'

      do_request(access_token: token.token,user_id: user.id, id: role.id)
      expect(status).to eq 200
    end
  end

  # add role to user
  put '/api/v1/users/:user_id/roles/:id' do
    with_options required: true do
      parameter :access_token, 'Access Token'
      parameter :user_id, 'User ID'
      parameter :id, 'Role ID'
    end
    example 'Add a role to a user' do
      explanation 'Returns user''s title string after the add'

      do_request(access_token: token.token,user_id: user.id, id: new_role.id)
      expect(status).to eq 200
    end
  end

  # remove role from user
  delete '/api/v1/users/:user_id/roles/:id' do
    with_options required: true do
      parameter :access_token, 'Access Token'
      parameter :user_id, 'User ID'
      parameter :id, 'Role ID'
    end
    example 'Remove a role from a user' do
      explanation 'Returns user''s title string after the role has been removed'

      do_request(access_token: token.token,user_id: user.id, id: role.id)
      expect(status).to eq 200
    end
  end
end