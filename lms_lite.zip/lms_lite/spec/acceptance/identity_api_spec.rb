require "rails_helper"
require "rspec_api_documentation/dsl"

resource "Identity" do
  let(:application) { create_application }
  let(:site) { FactoryBot.create(:site) }
  let(:user) { FactoryBot.create(:user, sites: [site]) }
  let(:token) { create_token(application.id, user.id) }
  let(:payload) { { token: token.token }.to_json }

  post "/identity/api/v1/token" do
    header 'Content-Type', 'application/json'
    header 'Accept', 'application/json'

    let(:raw_post) { payload }

    example "Token Response" do
      explanation "Validates and decodes token."
      do_request
      expect(status).to be 200
    end
  end
end
