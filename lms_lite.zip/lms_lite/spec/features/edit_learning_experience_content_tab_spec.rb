require 'rails_helper'

feature 'Edit Learning Experience Content Tab' do
  let(:site) { FactoryBot.create(:site) }
  let!(:user) { FactoryBot.create(:user, sites: [site]) }
  let!(:licensed_content) { FactoryBot.create(:licensed_content, site: site) }
  let!(:licensed_content_doppelganger) { FactoryBot.create(:licensed_content, site: site) }
  let!(:learning_experience) { FactoryBot.create(:learning_experience, site: site) }
  let(:edit_learning_experience_page) { Pages::EditLearningExperiencePage.new }
  let(:add_content_modal) { Pages::AddContentModal.new }
  let(:confirm_modal) { Pages::ConfirmModal.new }

  before(:each) do
    login_as(user)
    edit_learning_experience_page.visit_page(learning_experience)
    expect(edit_learning_experience_page).to be_on_page
  end

  context 'Content Tab' do
    scenario 'Can add content', :js do
      edit_learning_experience_page.click_on_add_content
      expect(add_content_modal).to be_shown
      add_content_modal.select_content(licensed_content.id)
      add_content_modal.click_on_add_content
      expect(edit_learning_experience_page).to be_on_page
      expect(edit_learning_experience_page.contents_table)
        .to match_array([{ 'Content Title' => licensed_content.title }])
    end

    context 'Content is already assigned' do
      before do
        learning_experience.licensed_contents = [licensed_content, licensed_content_doppelganger]
        edit_learning_experience_page.visit_page(learning_experience)
        expect(edit_learning_experience_page).to be_on_page
      end

      scenario 'Can remove content', :js do
        licensed_contents_to_remove = licensed_content
        expect(edit_learning_experience_page.contents_table)
          .to include(include({ 'Content Title' => licensed_contents_to_remove.title }))
        edit_learning_experience_page.select_content(licensed_contents_to_remove.id)
        edit_learning_experience_page.click_on_delete_checked_content
        confirm_modal.click_delete
        expect(edit_learning_experience_page.contents_table)
          .not_to include(include({ 'Content Title' => licensed_contents_to_remove.title }))
      end

      scenario 'Can remove all content', :js do
        edit_learning_experience_page.click_on_delete_all_content
        confirm_modal.click_delete_all
        expect(edit_learning_experience_page.contents_table)
          .to include(include({ 'Content Title' => nil }))
      end
    end
  end
end
