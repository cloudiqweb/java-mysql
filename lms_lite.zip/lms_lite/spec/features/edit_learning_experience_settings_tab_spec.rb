require 'rails_helper'

feature 'Edit Learning Experience Settings Tab' do
  let!(:site) { FactoryBot.create(:site) }
  let!(:user) { FactoryBot.create(:user, sites: [site], password: 'password') }

  let!(:learning_experience) { FactoryBot.create(:learning_experience, site: site) }
  let(:edit_learning_experience_page) { Pages::EditLearningExperiencePage.new }
  let(:learning_experiences_page) { Pages::LearningExperiencesPage.new }
  let(:confirm_modal) { Pages::ConfirmModal.new }

  before do
    # login_as user
    edit_learning_experience_page.log_in(login: user.email, password: 'password')
    edit_learning_experience_page.visit_page(learning_experience)
    edit_learning_experience_page.click_on_tab('settings-tab')
  end

  context 'Settings Tab' do
    scenario 'Can edit fields', :js do
      edit_learning_experience_page.fill_in_title("Edit Test")
      edit_learning_experience_page.click_on_save
      expect(edit_learning_experience_page)
        .to have_success('Learning experience was successfully updated.')
    end
  end

  scenario 'Can remove learning experience', :js do
    learning_experience_name = learning_experience.title
    edit_learning_experience_page.click_on_remove_learning_experience
    confirm_modal.click_confirm
    expect(learning_experiences_page).to be_on_page
    expect(learning_experiences_page)
      .to have_success('Learning experience was successfully destroyed.')
    expect(learning_experiences_page.learning_experiences_table_table)
      .not_to include(include({ 'Name' => learning_experience_name }))
  end
end
