require "rails_helper"

describe "Logging In" do
  let(:login_page) { Pages::LoginPage.new }
  let(:account_page) { Pages::AccountPage.new }
  let(:site) { FactoryBot.create(:site) }
  let(:user) { FactoryBot.create(:user,
                                 sites: [site],
                                 username: "egon.s",
                                 email: "egon@gbhq.com",
                                 password: "password") }

  context "with an email address" do
    scenario "with correct credentials" do
      login_page.log_in(login: user.email, password: "password")
      expect(account_page).to be_on_page
    end

    scenario "with incorrect credentials" do
      login_page.log_in(login: user.email, password: "wrong-password")
      expect(login_page).to have_error "Invalid Login or password."
    end
  end

  context "with a user name" do
    before do
      user.update_attribute(:email, nil)
    end

    scenario "with correct credentials" do
      login_page.log_in(login: user.username, password: "password")
      expect(account_page).to be_on_page
    end

    scenario "with incorrect credentials" do
      login_page.log_in(login: user.username, password: "wrong-password")
      expect(login_page).to have_error "Invalid Login or password."
    end
  end
end
