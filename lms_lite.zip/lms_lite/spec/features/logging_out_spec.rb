require "rails_helper"

describe "Logging Out" do
  let(:account_page) { Pages::AccountPage.new }
  let(:login_page) { Pages::LoginPage.new }
  let(:site) { FactoryBot.create(:site) }
  let(:user) { FactoryBot.create(:user,
                                 sites: [site],
                                 username: "egon.s",
                                 email: "egon@gbhq.com",
                                 password: "password") }

  before do
    login_page.log_in(login: user.email, password: "password")
  end

  scenario "with correct credentials" do
    expect(account_page).to be_on_page
    account_page.log_out
    expect(login_page).to be_on_page
    expect(login_page).to have_error "You need to sign in or sign up before continuing."
  end
end
