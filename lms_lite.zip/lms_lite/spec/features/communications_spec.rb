require 'rails_helper'

feature 'Communication' do
  let!(:site) { FactoryBot.create(:site) }
  let!(:user) { FactoryBot.create(:user, sites: [site]) }
  let!(:group) { FactoryBot.create(:group, site: site) }

  let(:communications_page) { Pages::CommunicationsPage.new }
  let(:create_message_page) { Pages::CreateMessagePage.new }

  let(:subject_text) { Faker::Company.name }
  let(:message_text) { Faker::Lorem.paragraph }

  before(:each) do
    login_as(user)
    communications_page.visit_page
  end

  scenario 'A new message can be created and shows in inbox and sent', :js do
    expect(communications_page).to be_on_page
    communications_page.click_on_new_message
    expect(create_message_page).to be_on_page
    create_message_page.fill_in_subject(subject_text)
    create_message_page.fill_in_send_to_users([user])
    create_message_page.fill_in_send_to_groups([group])
    create_message_page.fill_in_message(message_text)
    create_message_page.click_on_send
    expect(communications_page).to be_on_page
    expect(communications_page).to have_success('Your message has been successfully sent!')
    expect(communications_page).to be_on_sent_tab
    expect(communications_page.sent_table)
      .to include(include({ 'Subject' => subject_text,
                           'Sent To' => "#{user.name}, #{group.name}" }))
  end
end
