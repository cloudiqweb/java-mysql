require 'rails_helper'

feature 'Edit Learning Experience Groups Tab' do
  let(:site) { FactoryBot.create(:site) }
  let!(:user) { FactoryBot.create(:user, sites: [site]) }
  let!(:learning_experience) { FactoryBot.create(:learning_experience, site: site) }
  let!(:groups) { FactoryBot.create_list(:group, 3, site: site) }
  let(:add_groups_modal) { Pages::AddGroupsModal.new }
  let(:edit_learning_experience_page) { Pages::EditLearningExperiencePage.new }
  let(:confirm_modal) { Pages::ConfirmModal.new }

  before(:each) do
    login_as(user)
    edit_learning_experience_page.visit_page(learning_experience)
    edit_learning_experience_page.click_on_tab('groups-tab')
  end

  context 'Groups Tab' do
    scenario 'Can add groups', :js do
      edit_learning_experience_page.click_on_add_groups
      expect(add_groups_modal).to be_shown
      add_groups_modal.select_group(groups.first.id)
      add_groups_modal.click_add_group
      expect(edit_learning_experience_page.groups_table)
        .to match_array([{ 'Name' => groups.first.name }])
    end

    context 'Groups already assigned' do
      before do
        learning_experience.groups = groups
        edit_learning_experience_page.visit_page(learning_experience)
        edit_learning_experience_page.click_on_tab('groups-tab')
      end
      scenario 'Can remove a group', :js do
        group_to_remove = groups.first
        expect(edit_learning_experience_page.groups_table)
          .to include(include({ 'Name' => group_to_remove.name}))
        edit_learning_experience_page.select_group(group_to_remove.id)
        edit_learning_experience_page.click_on_delete_checked_groups
        confirm_modal.click_delete
        expect(edit_learning_experience_page.groups_table)
          .not_to include(include({ 'Name' => group_to_remove.name}))
      end

      scenario 'Can remove all groups', :js do
        sample_group = groups.sample
        expect(edit_learning_experience_page.groups_table)
          .to include(include({ 'Name' => sample_group.name}))
        edit_learning_experience_page.click_on_delete_all_groups
        confirm_modal.click_delete_all
        expect(edit_learning_experience_page.groups_table)
          .to include(include({'Name' => nil}))
      end
    end
  end
end
