require 'rails_helper'

feature 'Learning Experience Creation' do
  let!(:site) { FactoryBot.create(:site) }
  let!(:user) { FactoryBot.create(:user, sites: [site]) }

  let(:learning_experiences_page) { Pages::LearningExperiencesPage.new }
  let(:new_learning_experience_page) { Pages::CreateLearningExperiencePage.new }
  let(:edit_learning_experience_page) { Pages::EditLearningExperiencePage.new }
  let(:title) { Faker::Company.name }
  let(:description) { Faker::Lorem.paragraph }

  before(:each) do
    login_as(user)
    learning_experiences_page.visit_page
  end

  scenario 'A new Learning Experience can be created', :js do
    expect(learning_experiences_page).to be_on_page
    learning_experiences_page.click_on_new
    expect(new_learning_experience_page).to be_on_page

    new_learning_experience_page.fill_in_title(title)
    new_learning_experience_page.fill_in_description(description)
    new_learning_experience_page.toggle_status
    new_learning_experience_page.select_type('Course')
    new_learning_experience_page.click_save

    expect(edit_learning_experience_page).to be_on_page
    expect(edit_learning_experience_page).to have_summary(title, description, 'Active')

    expect(edit_learning_experience_page).to be_on_settings_tab
    expect(edit_learning_experience_page.title_field).to eq(title)
    expect(edit_learning_experience_page.description_field).to eq(description)
    expect(edit_learning_experience_page)
      .to have_learning_experience_type_selected('Course')
  end
end
