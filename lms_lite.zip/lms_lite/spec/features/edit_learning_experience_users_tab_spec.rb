require 'rails_helper'

feature 'Edit Learning Experience Users Tab' do
  let(:site) { FactoryBot.create(:site) }
  let!(:user) { FactoryBot.create(:user, sites: [site]) }
  let!(:learning_experience) { FactoryBot.create(:learning_experience, site: site) }
  let!(:test_learner) { FactoryBot.create(:user, sites: [site]) }
  let!(:doppelganger_learner) { FactoryBot.create(:user, sites: [site]) }
  let(:edit_learning_experience_page) { Pages::EditLearningExperiencePage.new }
  let(:add_users_modal) { Pages::AddUsersModal.new }
  let(:confirm_modal) { Pages::ConfirmModal.new }

  before(:each) do
    login_as(user)
    edit_learning_experience_page.visit_page(learning_experience)
    edit_learning_experience_page.click_on_tab('users-tab')
  end

  context 'Users Tab' do
    scenario 'Can add users', :js do
      edit_learning_experience_page.click_on_add_users
      expect(add_users_modal).to be_shown
      add_users_modal.select_user(test_learner.id)
      add_users_modal.click_add_users
      expect(edit_learning_experience_page.users_table)
        .to match_array([{'Username' => test_learner.username}])
    end

    context 'Users already assigned' do
      before do
        learning_experience.users = [test_learner, doppelganger_learner]
        edit_learning_experience_page.visit_page(learning_experience)
        edit_learning_experience_page.click_on_tab('users-tab')
      end

      scenario 'Can remove user', :js do
        user_to_remove = test_learner
        expect(edit_learning_experience_page.users_table)
          .to include(include({ 'Username' => user_to_remove.username }))
        edit_learning_experience_page.select_user(user_to_remove.id)
        edit_learning_experience_page.click_on_delete_checked_users
        confirm_modal.click_delete
        expect(edit_learning_experience_page.users_table)
          .not_to include(include({ 'Username' => user_to_remove.username }))
      end

      scenario 'Can remove all users', :js do
        sample_user = doppelganger_learner
        expect(edit_learning_experience_page.users_table)
          .to include(include({ 'Username' => sample_user.username }))
        edit_learning_experience_page.click_on_delete_all_users
        confirm_modal.click_delete_all
        expect(edit_learning_experience_page.users_table)
          .to include(include({ 'Username' => nil }))
      end
    end
  end
end
