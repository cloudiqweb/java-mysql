require 'rails_helper'

RSpec.describe CommunicationDecorator, type: :decorator do
  let!(:site) { FactoryBot.create(:site) }
  let!(:group) { FactoryBot.create(:group, site: site) }
  let!(:user) { FactoryBot.create(:user, sites: [site]) }
  let!(:sender) { FactoryBot.create(:user, sites: [site]) }
  let!(:communication) { FactoryBot.create(:communication, user: sender, site: site) }

  describe '#recipient_names' do
    context 'communication sent to all types' do
      before do
        communication.users << user
        communication.groups << group
      end

      it 'returns recipient names of users, and groups' do
        expect(communication.decorate.recipient_names)
          .to eq("#{user.name}, #{group.name}")
      end
    end

    context 'communication sent to some types' do
      before do
        communication.groups << group
      end

      it 'returns recipient names of groups' do
        expect(communication.decorate.recipient_names)
          .to eq("#{group.name}")
      end
    end
  end
end
