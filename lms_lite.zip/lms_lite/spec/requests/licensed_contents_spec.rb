require 'rails_helper'

RSpec.describe "LicensedContents", type: :request do
  let!(:site) { FactoryBot.create(:site) }
  let!(:user) { FactoryBot.create(:user, sites: [site]) }

  before(:each) do
    login_as(user)
  end

  describe "GET /licensed_contents" do
    it "works! (now write some real specs)" do
      get licensed_contents_path
      expect(response).to have_http_status(200)
    end
  end
end
