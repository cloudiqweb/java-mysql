require "rails_helper"

RSpec.describe "Identity management", type: :request do
  let(:application) { create_application }
  let(:site) { FactoryBot.create(:site) }
  let(:user) { FactoryBot.create(:user, sites: [site]) }
  let!(:token) { create_token(application.id, user.id) }

  describe "POST /identity/api/v1/token" do
    context "with a valid token" do
      let(:payload) { { token: token.token }.to_json }

      before do
        post "/identity/api/v1/token", params: payload, headers: default_headers
      end

      it "responds with 200" do
        expect(response.status).to eq 200
      end

      it "returns a valid response that includes the user's email and site UUID" do
        skip "site UUID functionality pending"
        payload = JSON.parse(response.body)["_payload"]
        expect(payload["valid"]).to be true
        expect(payload["subject"]["email"]).to eq user.email
        expect(payload["subject"]["site_uuid"]).to eq user.selected_site_uuid
      end
    end

    context "with an invalid token" do
      let(:payload) { { token: "badtokenvalue" }.to_json }

      before do
        post "/identity/api/v1/token", params: payload, headers: default_headers
      end

      it "responds with 401" do
        expect(response.status).to eq 401
      end

      it "contains an error message in the response" do
        error = JSON.parse(response.body)["_error"]
        expect(error["message"]).to eq "The token was expired or not valid"
      end
    end
  end

  describe "POST /identity/api/v1/credentials/password" do
    context "with good login credentials" do
      let(:payload) { { username: "glm", password: "password" }.to_json }

      before do
        post "/identity/api/v1/credentials/password", params: payload, headers: default_headers
      end

      it "responds with 200" do
        expect(response.status).to eq 200
      end

      it "should be a valid context" do
        payload = JSON.parse(response.body)["_payload"]
        expect(payload["valid"]).to be true
      end
    end

    context "with bad login credentials" do
      let(:payload) { { username: "egon", password: "password" }.to_json }

      before do
        post "/identity/api/v1/credentials/password", params: payload, headers: default_headers
      end

      it "responds with 200" do
        expect(response.status).to eq 401
      end

      it "should be a valid context" do
        payload = JSON.parse(response.body)["_payload"]
        expect(payload["valid"]).to be false
      end
    end
  end
end
