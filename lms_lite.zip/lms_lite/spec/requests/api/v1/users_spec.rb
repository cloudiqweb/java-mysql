require "rails_helper"

RSpec.describe "Users API", type: :request do
  let(:application) { create_application }
  let(:site) { FactoryBot.create(:site) }
  let(:user) { FactoryBot.create(:user, sites: [site]) }
  let!(:token) { create_token(application.id, user.id) }

  let(:site_ids) { [site.id] }
  let(:password) { "password" }
  let(:username) { Faker::Internet.user_name + SecureRandom.uuid.delete('-') }
  let(:email) { "#{SecureRandom.uuid.delete('-')}@apitest.mediapro.com" }
  let(:given_name) { Faker::Name.first_name }
  let(:family_name) { Faker::Name.last_name }
  let(:middle_name) { Faker::Name.first_name }
  let(:department) { Faker::Team.creature }
  let(:comments) { Faker::Lorem.sentence }

  # Brought over from ARL
  describe "GET /api/v1/me" do
    it "responds with 200" do
      get api_v1_me_path, params: { access_token: token.token }
      expect(response.status).to eq 200
    end

    it "returns the user as json" do
      get api_v1_me_path, params: { access_token: token.token }
      result = user.as_json(methods: :site_uuid).to_json
      expect(response.body).to eq result
    end
  end

  # Test suite for GET /api/v1/users/:id
  describe 'GET /api/v1/users/:id' do
    
    let(:user_id) { site.users.first.id }

    before do 
      get api_v1_user_path(user_id), params: { access_token: token.token }
    end

    context 'when the user record exists' do
      it 'returns the user' do
        expect(json).not_to be_empty
        expect(json['id']).to eq(user_id)
      end

      it 'returns status code 200' do
        expect(status).to be 200
      end
    end

    context 'when the user record does not exist' do
      # asssign user_id to one that doesn't not exist
      let(:user_id) { site.users.last.id + 1 }

      it 'returns status code 404' do
        expect(status).to be 404
      end

      it 'returns a not found message' do
        expect(response.body).to match(/Couldn't find User/)
      end
    end
  end

  # Test suite for POST /api/v1/users/
  describe 'POST /api/v1/users/' do
    before do
      post api_v1_users_path, params: { 
        access_token: token.token, 
        site_ids: site_ids,
        password: password,
        username: username,
        email: email,
        given_name: given_name,
        family_name: family_name,
        middle_name: middle_name,
        department: department,
        comments: comments
      }
    end

    context 'when a request is valid' do
      it 'creates a user' do
        expect(json["id"]).to be > 0
        expect(json["username"]).to eq username
        expect(json["email"]).to eq email 
        expect(json["given_name"]).to eq given_name 
        expect(json["family_name"]).to eq family_name 
        expect(json["middle_name"]).to eq middle_name 
        expect(json["department"]).to eq department 
        expect(json["comments"]).to eq comments 
      end

      it 'returns status code 201' do
        expect(status).to be 201
      end
    end

    context 'when a request is invalid' do
      context 'password is not present' do
        before do
          post api_v1_users_path,params: { 
            access_token: token.token, 
            site_ids: site_ids,
            username: Faker::Internet.user_name + SecureRandom.uuid.delete('-'),
            email: "#{SecureRandom.uuid.delete('-')}@apitest.mediapro.com",
            password: ""
          }
        end

        it 'returns status code 422' do
          expect(response).to have_http_status(422)
        end

        it 'returns a validation failure message' do
          expect(response.body)
            .to match(/Validation failed: Password can't be blank/)
        end
      end

      context 'username and email not present' do
        before do
          post api_v1_users_path, params: { 
            access_token: token.token, 
            site_ids: site_ids,
            password: password,
            username: "",
            email: "",
            given_name: given_name,
            family_name: family_name,
            middle_name: middle_name,
            department: department,
            comments: comments
          }
        end

        it 'returns status code 422' do
          expect(response).to have_http_status(422)
        end

        it 'returns a validation failure message' do
          expect(response.body)
            .to match(/Validation failed: Email or Username must be present/)
        end
      end
    end
  end


  # Test suite for PUT /api/v1/users/:id
  describe 'PUT /api/v1/users/:id' do
    context 'when user exists' do
      before do
        put api_v1_user_path(user.id), params: { 
          access_token: token.token, 
          site_ids: site_ids,
          password: password,
          username: username,
          email: email,
          given_name: given_name,
          family_name: family_name,
          middle_name: middle_name,
          department: department,
          comments: comments
        }
      end

      it 'updates the record' do
        expect(response.body).to be_empty
      end

      it 'returns status code 204' do
        expect(status).to be 204
      end
    end

    context 'when user does not exist' do
      before do
        put api_v1_user_path(0), params: { 
          access_token: token.token, 
          site_ids: site_ids,
          password: password,
          username: username,
          email: email,
          given_name: given_name,
          family_name: family_name,
          middle_name: middle_name,
          department: department,
          comments: comments
        }
      end

      it 'returns status code 404' do
        expect(status).to be 404
      end

      it 'returns a not found message' do
        expect(response.body).to match(/Couldn't find User/)
      end
    end

    context 'when a request is invalid' do
      context 'password is not present' do
        before do
          put api_v1_user_path(user.id),params: { 
            access_token: token.token, 
            site_ids: site_ids,
            username: Faker::Internet.user_name + SecureRandom.uuid.delete('-'),
            email: "#{SecureRandom.uuid.delete('-')}@apitest.mediapro.com",
            password: ""
          }
        end

        it 'returns status code 422' do
          expect(response).to have_http_status(422)
        end

        it 'returns a validation failure message' do
          expect(response.body)
            .to match(/Validation failed: Password can't be blank/)
        end
      end

      context 'username and email not present' do
        before do
          put api_v1_user_path(user.id), params: { 
            access_token: token.token, 
            site_ids: site_ids,
            password: password,
            username: "",
            email: "",
            given_name: given_name,
            family_name: family_name,
            middle_name: middle_name,
            department: department,
            comments: comments
          }
        end

        it 'returns status code 422' do
          expect(response).to have_http_status(422)
        end

        it 'returns a validation failure message' do
          expect(response.body)
            .to match(/Validation failed: Email or Username must be present/)
        end
      end
    end
  end

  # Test suite for DELETE /api/v1/users/:id
  describe 'DELETE /api/v1/users/:id' do
    context 'when user exists' do
      before do
        delete api_v1_user_path(user.id), params: { access_token: token.token }
      end

      it 'returns status code 204' do
        expect(status).to be 204
      end
    end

    context 'when user does not exist' do
      before do
        delete api_v1_user_path(user.id + 1), params: { access_token: token.token }
      end

      it 'returns status code 404' do
        expect(status).to be 404
      end

      it 'returns a not found message' do
        expect(response.body).to match(/Couldn't find User/)
      end
    end
  end
end