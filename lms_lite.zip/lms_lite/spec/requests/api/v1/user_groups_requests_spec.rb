require "rails_helper"

RSpec.describe "User Groups API", type: :request do
  let(:application) { create_application }
  let(:site) { FactoryBot.create(:site) }
  let!(:user_group) { FactoryBot.create(:user_group, site: site) }
  let(:user) { FactoryBot.create(:user, sites: [site]) }
  let!(:token) { create_token(application.id, user.id) }

  # Test uiste for GET /api/v1/user_groups/
  describe "GET /api/v1/user_groups" do
    let!(:another_user_group) { FactoryBot.create(:user_group) }

    before do
      get api_v1_user_groups_path, params: { access_token: token.token }
    end

    it "returns status code 200" do
      expect(response).to have_http_status(200)
    end

    it "returns a list of user groups" do
      expect(json.count).to eq 2
      expect(json.first["name"]).to eq user_group.name
      expect(json.second["name"]).to eq another_user_group.name
    end
  end

  # Test suite for POST /api/v1/user_groups/
  describe "POST /api/v1/user_groups/" do
    let(:name) { "Test User Group" }

    context "when request is valid" do
      before do
        post api_v1_user_groups_path,
          params: { access_token: token.token, name: name }
      end

      it "creates a user group" do
        expect(json["name"]).to eq name
      end

      it "returns status code 201" do
        expect(response).to have_http_status(201)
      end
    end

    context "when request is invalid" do
      context "when name is not present" do
        before do
          post api_v1_user_groups_path, params: { access_token: token.token }
        end

        it "returns status code 422" do
          expect(response).to have_http_status(422)
        end

        it "returns a validation failure message" do
          expect(response.body)
            .to match(/Validation failed: Name can't be blank/)
        end
      end

      context "when name is too short" do
        before do
          post api_v1_user_groups_path,
            params: { access_token: token.token, name: "GB" }
        end

        it "returns status code 422" do
          expect(response).to have_http_status(422)
        end

        it "returns a validation failure message" do
          expect(response.body)
            .to match(/Validation failed: Name is too short/)
        end
      end
    end
  end

  # Test suite for GET /api/v1/user_groups/:id
  describe "GET /api/v1/user_groups/:id" do
    context "when user group exists" do
      before do
        get api_v1_user_group_path(user_group.id),
          params: { access_token: token.token }
      end

      it "returns user group" do
        expect(json).to_not be_empty
        expect(json["name"]).to eq user_group.name
      end

      it "returns status code 200" do
        expect(response).to have_http_status(200)
      end
    end

    context "when record does not exist" do
      before do
        get api_v1_user_group_path(9999), params: { access_token: token.token }
      end

      it "returns status code 404" do
        expect(response).to have_http_status(404)
      end

      it "returns a not found message" do
        expect(response.body).to match(/Couldn't find UserGroup/)
      end
    end
  end

  # Test suite for PUT /api/v1/user_groups/:id
  describe "PUT /api/v1/user_groups/:id" do
    context "when user group exists" do
      before do
        put api_v1_user_group_path(user_group.id),
          params: { access_token: token.token, name: "First Ghostbusters" }
      end

      it "updates the record" do
        expect(response.body).to be_empty
      end

      it "returns status code 204" do
        expect(response).to have_http_status(204)
      end
    end

    context "when user group exists but param is bad" do
      before do
        put api_v1_user_group_path(user_group.id),
          params: { access_token: token.token, name: "GB" }
      end

      it "returns status code 422 when param is invalid" do
        expect(response).to have_http_status(422)
      end
    end

    context "when user group does not exist" do
      before do
        put api_v1_user_group_path(user_group.id + 1),
          params: { access_token: token.token, name: "First Ghostbusters" }
      end

      it "returns status code 404" do
        expect(response).to have_http_status(404)
      end

      it "returns a not found message" do
        expect(response.body).to match(/Couldn't find UserGroup/)
      end
    end
  end

  # Test suite for DELETE /api/v1/user_groups/:id
  describe "DELETE /api/v1/user_groups/:id" do
    context "when user group exists" do
      before do
        delete api_v1_user_group_path(user_group.id),
          params: { access_token: token.token }
      end

      it "returns status code 204" do
        expect(response).to have_http_status(204)
      end
    end

    context "when user group does not exist" do
      before do
        delete api_v1_user_group_path(9999),
          params: { access_token: token.token }
      end

      it "returns status code 404" do
        expect(response).to have_http_status(404)
      end

      it "returns a not found message" do
        expect(response.body).to match(/Couldn't find UserGroup/)
      end
    end
  end
end

