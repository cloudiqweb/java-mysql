require "rails_helper"

RSpec.describe "Roles API", type: :request do
  let(:application) { create_application }
  let(:site) { FactoryBot.create(:site) }
  let(:role) { Role.create(name: "mp admin") }
  let(:new_role) { Role.create(name: "learner") }
  let(:user) { FactoryBot.create(:user, sites: [site], roles: [role] ) }
  let!(:token) { create_token(application.id, user.id) }

  # show all roles
  describe 'GET /api/v1/users/:user_id/roles' do
    context "when user is found" do
      before do
        get api_v1_user_roles_path(user), params: { access_token: token.token}
      end

      it 'returns status code 200' do
        expect(response).to have_http_status(200)
      end

      it 'returns titles for user' do
        expect(json['roles']).to eq "mp admin"
      end
    end

    context "when user has no roles" do
      let(:no_roles_user) { FactoryBot.create(:user, sites: [site] ) }
      before do
        get api_v1_user_roles_path(no_roles_user), params: { access_token: token.token}
      end

      it 'returns status code 200' do
        expect(response).to have_http_status(200)
      end

      it 'returns empty string' do
        expect(json['roles']).to be_empty
      end
    end

    context "when user is not found" do
      before do
        get api_v1_user_roles_path(0), params: { access_token: token.token}
      end
      it 'returns status code 404' do
        expect(response).to have_http_status(404)
      end

      it 'returns user not found' do
        expect(response.body).to match(/Couldn't find User/)
      end
    end
  end

  # user has a role roles
  describe 'GET /api/v1/users/:user_id/roles/:id' do
    context 'when a user has role' do
      before do 
        get api_v1_user_role_path(user, role), params: { access_token: token.token }
      end
      it 'returns a boolean if the user has the role' do
        expect(json['match']).to be true
      end

      it 'returns status code 200' do
        expect(status).to be 200
      end
    end
    context 'when a user has no roles' do
      before do 
        get api_v1_user_role_path(user, 100), params: { access_token: token.token }
      end
      it 'returns a boolean if the user has the role' do
        expect(json['match']).to be false
      end

      it 'returns status code 200' do
        expect(status).to be 200
      end
    end
  end

  # add a role
  describe 'PUT /api/v1/users/:user_id/roles/:role' do
    context 'when a user does not have a role' do
      before do
        put api_v1_user_role_path(user,new_role), params: { 
          access_token: token.token
        }
      end
      it 'adds a role to a user and returns titles' do
        expect(json['roles']).to match(/mp admin, learner/)
      end

      it 'returns status code 200' do
        expect(status).to be 200
      end
    end

    context 'when a user already has the role' do
      before do
        put api_v1_user_role_path(user,role), params: { 
          access_token: token.token
        }
      end
      it 'does not add a duplicate role returns titles' do
        expect(response.body).to match(/Validation failed: User role already assigned/)
      end

      it 'returns status code 200' do
        expect(status).to be 422
      end
    end
  end

  # remove a role
  describe ' DELETE /api/v1/users/:user_id/roles/:id' do
    context 'when user and role exist' do
      before do
        delete api_v1_user_role_path(user, role), params: { access_token: token.token }
      end

      it 'removes a role from a user and returns titles' do
        expect(JSON.parse(response.body)["roles"]).to be_empty
      end

      it 'returns status code 200' do
        expect(status).to be 200
      end
    end
    context 'when user does not have the role' do
      let(:no_role) { Role.create(name: "another_one") }
      before do
        delete api_v1_user_role_path(user, no_role), params: { access_token: token.token }
      end

      it 'removes a role from a user and returns titles' do
        expect(response.body).to match(/mp admin/)
      end

      it 'returns status code 200' do
        expect(status).to be 200
      end
    end
  end
end