require 'rails_helper'

RSpec.describe 'Sites API', tyep: :request do
  let(:application) { create_application }
  let(:site) { FactoryBot.create(:site) }
  let!(:site_two) { FactoryBot.create(:site) }
  let(:user) { FactoryBot.create(:user, sites: [site]) }
  let!(:token) { create_token(application.id, user.id) }

  # Test suite for GET /api/v1/sites/
  describe 'GET /api/v1/sites' do
    let!(:another_site) { FactoryBot.create(:site) }

    before do
      get api_v1_sites_path, params: { access_token: token.token }
    end

    it 'returns status code 200' do
      expect(response).to have_http_status(200)
    end

    it 'returns a list of sites' do
      response_json = JSON.parse(response.body)
      expect(response_json.count).to eq 3
      expect(response_json).to include(include({ 'name' => site.name }))
      expect(response_json).to include(include({ 'name' => another_site.name }))
      expect(response_json).to include(include({ 'name' => site_two.name }))
    end
  end

  # Test suite for POST /api/v1/sites/
  describe 'POST /api/v1/sites/' do
    before do
      post api_v1_sites_path, params: { access_token: token.token, name: 'site test' }
    end

    context 'when request is valid' do
      it 'creates a site' do
        expect(json['name']).to eq('site test')
      end

      it 'returns status code 201' do
        expect(response).to have_http_status(201)
      end
    end

    context 'when request is invalid' do
      context 'when name param is not present' do
        before do
          post api_v1_sites_path, params: { access_token: token.token }
        end

        it 'returns status code 422' do
          expect(response).to have_http_status(422)
        end

        it 'returns a validation failure message' do
          expect(response.body)
            .to match(/Validation failed: Name can't be blank/)
        end
      end

      context 'when site name is already taken' do
        before do
          post api_v1_sites_path, params: { access_token: token.token, name: site_two.name }
        end

        it 'returns status code 422' do
          expect(response).to have_http_status(422)
        end

        it 'returns a validation failure message' do
          expect(response.body)
            .to match(/Validation failed: Name has already been taken/)
        end
      end
    end
  end

  # Test suite for GET /api/v1/sites/:id
  describe 'GET /api/v1/sites/:id' do
    context 'when site exists' do
      before do
        get api_v1_site_path(site.id), params: { access_token: token.token }
      end

      it 'returns site' do
        expect(json).not_to be_empty
        expect(json['name']).to eq site.name
        expect(json['site_uuid']).not_to be_empty
      end

      it 'returns status code 200' do
        expect(response).to have_http_status(200)
      end
    end

    context 'when record does not exist' do
      before do
        get api_v1_site_path(site.id + 1), params: { access_token: token.token }
      end

      it 'returns status code 404' do
        expect(response).to have_http_status(404)
      end

      it 'returns a not found message' do
        expect(response.body).to match(/Couldn't find Site/)
      end
    end
  end

  # Test suite for PUT /api/v1/sites/:id
  describe 'PUT /api/v1/sites/:id' do
    context 'when site exists' do
      before do
        put api_v1_site_path(site.id), params: { access_token: token.token, name: "foobar" }
      end

      it 'updates the record' do
        expect(response.body).to be_empty
      end

      it 'returns status code 204' do
        expect(response).to have_http_status(204)
      end
    end

    context 'when site exists but param is bad' do
      before do
        put api_v1_site_path(site.id), params: { access_token: token.token, name: "" }
      end

      it 'returns status code 422 when param is invalid' do
        expect(response).to have_http_status(422)
      end

      it 'returns a validation failure message' do
        expect(response.body)
          .to match(/Validation failed: Name can't be blank/)
      end
    end

    context 'when site name is already taken' do
      before do
        put api_v1_site_path(site.id), params: { access_token: token.token, name: site_two.name }
      end

      it 'returns status code 422 when param is invalid' do
        expect(response).to have_http_status(422)
      end

      it 'returns a validation failure message' do
        expect(response.body)
          .to match(/Validation failed: Name has already been taken/)
      end
    end

    context 'when site does not exist' do
      before do
        put api_v1_site_path(site.id + 1), params: { access_token: token.token, name: "foobar" }
      end

      it 'returns status code 404' do
        expect(response).to have_http_status(404)
      end

      it 'returns a not found message' do
        expect(response.body).to match(/Couldn't find Site/)
      end
    end
  end

  # Test suite for DELETE /api/v1/sites/:id
  describe 'DELETE /api/v1/sites/:id' do
    context 'when site exists' do
      before do
        delete api_v1_site_path(site.id), params: { access_token: token.token }
      end

      it 'returns status code 204' do
        expect(response).to have_http_status(204)
      end
    end

    context 'when site does not exist' do
      before do
        delete api_v1_site_path(site.id + 1), params: { access_token: token.token }
      end

      it 'returns status code 404' do
        expect(response).to have_http_status(404)
      end

      it 'returns a not found message' do
        expect(response.body).to match(/Couldn't find Site/)
      end
    end
  end
end