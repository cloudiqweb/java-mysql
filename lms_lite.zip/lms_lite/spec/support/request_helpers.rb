module RequestHelpers
  def json
    @json ||= JSON.parse(response.body)
  end

  def create_application
    Doorkeeper::Application.create!(
      name: "TestApp",
      redirect_uri: "https://identity.mediapro.com/users/auth/mediapro/callback"
    )
  end

  def create_token(application_id, user_id)
    Doorkeeper::AccessToken.create!(
      application_id: application_id, resource_owner_id: user_id
    )
  end

  def default_headers
    { "CONTENT_TYPE" => "application/json", "ACCEPT" => "application/json" }
  end

  def authenticated_headers(user)
    { "X-USER-TOKEN" => "#{user.auth_token}", "X-USER-EMAIL" => "#{user.email}" }.merge(default_headers)
  end

  def unauthenticated_headers
    { "X-USER-TOKEN" => nil }.merge(default_headers)
  end
end

