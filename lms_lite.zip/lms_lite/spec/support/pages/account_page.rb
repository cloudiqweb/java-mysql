module Pages
  class AccountPage < PageObject
    def visit_page
      visit root_path
    end

    def on_page?
      has_selector? "h1", text: "My Account"
    end

    def log_out
      find("#sign-out-button").click
    end
  end
end

