module Pages
  class CreateLearningExperiencePage < PageObject
    def on_page?
      has_selector? 'a#create-learning-experience-tab', text: 'Create'
    end

    def fill_in_title(title)
      fill_in 'learning_experience_title', with: title
    end

    def fill_in_description(description)
      fill_in 'learning_experience_description', with: description
    end

    def toggle_status
      find('.slider').click
    end

    def select_type(type)
      enum_value = Content.content_types[type]
      find('#learning_experience_experience_type').find("[value='#{enum_value}']")
                                                  .select_option
    end

    def fill_in_fields
      fill_in_title(Faker::Company.name)
      fill_in_description(Faker::Lorem.paragraph)
      toggle_status
      select_type('Course')
    end

    def click_save
      click_on "Save"
    end
  end
end
