module Pages
  class LearningExperiencesPage < PageObject
    def visit_page
      visit learning_experiences_path
    end

    def on_page?
      has_selector? 'h3', text: 'Learning Experiences'
    end

    def learning_experiences_table_table(columns = ['Title'])
      hashes_from_table('#learning-experiences-table').columns(*columns)
    end

    def click_on_new
      find('#new-learning-experience-button').click
    end
  end
end