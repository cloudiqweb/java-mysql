module Pages
  class CreateMessagePage < PageObject
    def on_page?
      has_selector? 'h3', text: 'New Message'
    end

    def fill_in_subject(text)
      fill_in 'communication_subject', with: text
    end

    def fill_in_send_to_users(users)
      users.each do |user|
        within '#send-to-users-form-controls' do
          find('span.select2-selection.select2-selection--multiple').click
        end

        within 'ul#select2-send_to_users-results' do
          all('li', text: user.name).first.click
        end
      end
    end

    def fill_in_send_to_groups(groups)
      groups.each do |group|
        within '#send-to-groups-form-controls' do
          find('span.select2-selection.select2-selection--multiple').click
        end

        within 'ul#select2-send_to_groups-results' do
          all('li', text: group.name).first.click
        end
      end
    end

    def fill_in_message(text)
      fill_in 'communication_message', with: text
    end

    def click_on_send
      click_on 'Send'
    end
  end
end