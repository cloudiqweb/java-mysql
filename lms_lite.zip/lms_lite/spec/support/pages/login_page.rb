module Pages
  class LoginPage < PageObject
    def visit_page
      visit root_path
    end

    def on_page?
      has_selector? "h2", text: "Log in"
    end
  end
end
