module Pages
  class CommunicationsPage < PageObject
    def visit_page
      visit communications_path
    end

    def on_page?
      has_content?('Inbox') && has_content?('Sent') && has_content?('New Message')
    end

    def click_on_inbox_tab
      click_on_tab('inbox')
    end

    def on_inbox_tab?
      on_tab_with_id?('inbox-tab-link')
    end

    def click_on_sent_tab
      click_on_tab('sent-tab')
    end

    def on_sent_tab?
      on_tab_with_id?('sent-tab-link')
    end

    def inbox_table(columns = ['Subject', 'From'])
      hashes_from_table('#inbox-table').columns(*columns)
    end

    def sent_table(columns = ['Subject', 'Sent To'])
      hashes_from_table('#sent-table').columns(*columns)
    end

    def click_on_subject(subject)
      click_on subject
    end

    def click_on_new_message
      click_on 'New Message'
    end
  end
end