module Pages
  class AddUsersModal < PageObject
    def shown?
      has_selector?('#add-users-modal', visible: true) &&
        has_selector?('h4', text: 'Add Users', visible: true)
    end

    def select_user(user_id)
      find("#users_[value='#{user_id}']").click
    end

    def click_add_users
      find('#add-users-modal-button').click
    end
  end
end