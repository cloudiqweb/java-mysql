module Pages
  class AddGroupsModal < PageObject
    def shown?
      has_selector?('#add-groups-modal', visible: true) &&
        has_selector?('h4', text: 'Add Groups', visible: true)
    end

    def select_group(group_id)
      find("#groups_[value='#{group_id}']").click
    end

    def click_add_group
      find('#add-groups-modal-button').click
    end
  end
end