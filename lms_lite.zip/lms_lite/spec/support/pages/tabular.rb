module Tabular
  module TableHelper
    def columns(*column_names)
      return self if column_names.blank?
      map {|row| row.slice(*column_names) }
    end
    alias column columns
  end

  def hashes_from_table(selector='table')
    actual = find(selector)
    headers = actual.all("th").map(&:text)
    actual.all("tbody tr").map do |row|
      Hash[headers.zip row.all("td").map(&parse_td_text).compact]
    end.extend TableHelper
  end

  def deedle_hash
    all('dl').map do |dl|
      dl.all('dt,dd').each_slice(2).map {|dt, dd| {dt.text => dd.text} }
    end.flatten.reduce :merge
  end

  private

  def parse_td_text
    ->(node) do
      case
      when node.all("i.fa-check").size == 1
        "✓"
      when node.all("a.btn").size > 0
        node.all("a.btn").map {|n| n['data-title'] }
      else
        node.text.strip
      end
    end
  end
end