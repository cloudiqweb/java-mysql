module Pages
  class EditLearningExperiencePage < PageObject
    def visit_page(learning_experience)
      visit learning_experience_path(learning_experience)
    end

    def on_page?
      has_selector? 'a#settings-tab', text: 'Settings'
    end

    def has_summary?(title, description, status)
      within '#content-library-sidebar .panel-body' do
        has_content?(title) &&
          has_content?(description) &&
          has_content?(status)
      end
    end

    def on_settings_tab?
      on_tab_with_id?('settings-tab')
    end

    def click_on_add_content
      find('#add-content-btn').click
    end

    def contents_table(columns = ['Content Title'])
      hashes_from_table('#contents-table').columns(*columns)
    end

    def click_on_delete_checked_content
      find('#delete-checked-content-btn').click
    end

    def click_on_delete_all_content
      find('#delete-all-content-btn').click
    end

    def click_on_remove_learning_experience
      click_on 'Remove Learning Experience'
    end

    def select_content(content_id)
      find("#licensed_contents_[value='#{content_id}']").click
    end

    def click_on_add_users
      find('#add-users-btn').click
    end

    def click_on_delete_checked_users
      find('#delete-checked-users-btn').click
    end

    def click_on_delete_all_users
      find('#delete-all-users-btn').click
    end

    def users_table(columns = ['Username'])
      hashes_from_table('#users-table').columns(*columns)
    end

    def select_user(user_id)
      find("#users_[value='#{user_id}']").click
    end

    def click_on_add_groups
      find('#add-groups-btn').click
    end

    def click_on_delete_checked_groups
      find('#delete-checked-groups-btn').click
    end

    def click_on_delete_all_groups
      find('#delete-all-groups-btn').click
    end

    def groups_table(columns = ['Name'])
      hashes_from_table('#groups-table').columns(*columns)
    end

    def select_group(group_id)
      find("#groups_[value='#{group_id}']").click
    end

    def title_field
      find('#learning_experience_title').value
    end

    def description_field
      find('#learning_experience_description').value
    end

    def has_learning_experience_type_selected?(type)
      find('#learning_experience_experience_type').find('option[selected]').text == type
    end

    def fill_in_title(text)
      fill_in('learning_experience_title', with: text)
    end

    def click_on_save
      click_on 'Save'
    end
  end
end
