module Pages
  class AddContentModal < PageObject
    def shown?
      has_selector?('#add-content-modal', visible: true) &&
        has_selector?('h4', text: 'Add Content', visible: true)
    end

    def content_list_visible?
      has_selector?('#licensed_contents_', visible: true)
    end

    def select_content(content_id)
      find("#licensed_contents_[value='#{content_id}']").click
    end

    def click_on_add_content
      find('#add-content-modal-button').click
    end
  end
end