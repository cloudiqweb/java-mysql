module Pages
  class ConfirmModal < PageObject
    def click_confirm
      click_confirm_button
    end

    def click_delete
      click_confirm_button("Delete")
    end

    def click_delete_all
      click_confirm_button("Delete All")
    end

    def click_remove
      click_confirm_button("Remove")
    end

    private

    def click_confirm_button(text="Confirm")
      has_selector?('.modal-footer', text: text)
      within '.modal-footer' do
        click_on text
      end
    end
  end
end