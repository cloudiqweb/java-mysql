module CommonHelpers
  def error_list(resource)
    resource.errors.full_messages.join(", ")
  end
end

