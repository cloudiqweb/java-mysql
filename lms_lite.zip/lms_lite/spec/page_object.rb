require Rails.root.join('spec', 'support', 'pages', 'tabular').to_s

class PageObject
  include Capybara::DSL
  include Tabular
  include Rails.application.routes.url_helpers
  include CapybaraErrorIntel::DSL

  def has_notice?(text, wait: Capybara.default_max_wait_time)
    page.has_selector?(".alert.alert-notice.fade.in", text: text, wait: wait)
  end

  def has_success?(text, wait: Capybara.default_max_wait_time)
    page.has_selector?(".alert.fade.in.alert-success", text: text, wait: wait)
  end

  def has_warning?(text, wait: Capybara.default_max_wait_time)
    page.has_selector?(".alert.alert-warning.fade.in", text: text, wait: wait)
  end

  def has_error?(text, wait: Capybara.default_max_wait_time)
    page.has_selector?(".alert.alert-danger.fade.in", text: text, wait: wait)
  end

  def within_parent(*find_args)
    within(*find_args) do
      within :xpath, ".." do
        yield
      end
    end
  end

  def wait_for_jquery
    Timeout.timeout(Capybara.default_max_wait_time) do
      loop until page.evaluate_script('jQuery.active').zero?
    end
  end

  def click_on_tab(tab_id)
    find("##{tab_id}").click
  end

  def on_tab_with_id?(tabpanel_id)
    has_selector? "li.active a##{tabpanel_id}"
  end

  def log_in(login:, password:)
    visit '/users/sign_in'
    find("#user_login").set(login)
    find("#user_password").set(password)
    find("#log-in-button").click
  end
end
