# README
# LMS Lite

## Setup

Make sure you're setup on [Bitbucket](https://bitbucket.mediapro.com:8443/dashboard) and can access the [repository](https://bitbucket.mediapro.com:8443/projects/SAAS/repos/lms_lite/browse), then clone the repo:

```
> git clone ssh://git@bitbucket.mediapro.com:7999/saas/lms_lite.git
Cloning into 'lms_lite'...
>

> cd lms_lite
>
```



Make sure [RVM](https://rvm.io/) or [rbenv](https://github.com/rbenv/rbenv) is properly configured to use the `.ruby-version` and `.ruby-gemset` files. Example:
```
> rvm current
ruby-2.5.0@lmslite
>
```

RVM offers a nifty hook on `cd` that may be useful if you're having a hard time setting up the ruby/gemset environment on your dev box. [Read more about it here.](https://rvm.io/integration/bundler#cd-hook)

Next you'll want to get your gems setup. Assuming RVM created a new gemset for you, be sure to install [Bundler](https://bundler.io/) and run `bundle install`:
```
> gem install bundler
Fetching: bundler-1.16.1.gem (100%)
Successfully installed bundler-1.16.1
1 gem installed
>

> bundle install
Fetching gem metadata from https://rubygems.org/............
Fetching rake 12.3.0
Fetching concurrent-ruby 1.0.5
Installing concurrent-ruby 1.0.5
Installing rake 12.3.0
... lots of fetching/installing lines ...
Bundle complete! 51 Gemfile dependencies, 127 gems now installed.
Use `bundle info [gemname]` to see where a bundled gem is installed.
... maybe some post-install messages from gems ...
>
```

Now setup your database using the [Rails command line](http://guides.rubyonrails.org/command_line.html). An initial set of seeds will be ran to initialize a local environment with some data:
```
> rails db:setup
Created database 'lms_lite_development'
Created database 'lms_lite_test'
-- enable_extension("plpgsql")
  -> 0.0175s
-- create_table("contents", {:force=>:cascade})
  -> 0.0751s
... more schema setup lines ...
[Seeds] Creating MediaPro site
[Seeds] Creating admin@mediapro.com user on MediaPro site
... more seeds lines ...
>
```

By default PostgreSQL connects to the PostgreSQL user with the same name as the current unix user. If you're getting an error similar to:
```
FATAL: role "myusername" does not exist

```

You will need to setup a role in postgres for your unix username. Login to your shell as the user `postgres` (postgres installation has already created that unix user for you) and then create new postgres user with the same name as your normal unix username:
```
# switch to postgres user
sudo -u postgres -i
# open postgres CLI
psql
# create user with same name as your ususal unix username
CREATE USER <username here> WITH SUPERUSER CREATEDB CREATEROLE LOGIN;
# Check that the new role has been created (you may need to use / instead of \ for xubuntu:
\du
# Output should look like this:
Role name |                         Attributes                         | Member of
-----------+------------------------------------------------------------+-----------
 <username here> | Superuser, Create role, Create DB                          | {}
 postgres        | Superuser, Create role, Create DB, Replication, Bypass RLS | {}

# Exit psql
\q

```
Now you can run `exit` or close this CLI and open another as your normal unix user and run `rake db:setup`

**Ubuntu users only** will need to add the phantomJS exec to their path in order for poltergeist to function correctly. [Download Here](https://github.com/teampoltergeist/poltergeist#installing-phantomjs)

To add the location to your `PATH`, you can edit your enviornment file:

```
sudo gedit /etc/environment
```

and prepending your path like so:
```
PATH="/the/path/to/your/bin/phantomjs:..."
```

You'll also need to generate a private key for authentication to work. Run the following commands:
```
mkdir /usr/local/etc/mediapro
openssl genpkey -algorithm RSA -out /usr/local/etc/mediapro/token_manager.pem -pkeyopt rsa_keygen_bits:2048
```

If you're using an older version of OpenSSL, `genpkey` may not be available for you. If you're on a mac, you can use an up-to-date homebrew'd OpenSSL instead! Example:
```
/usr/local/Cellar/openssl/1.0.2n/bin/openssl genpkey -algorithm RSA -out /usr/local/etc/mediapro/token_manager.pem -pkeyopt rsa_keygen_bits:2048
```

At this point, you should be ready to roll!

We use [RSpec](https://relishapp.com/rspec/rspec-core/v/3-7/docs) for testing. Run the tests using the `rspec` command:
```
> rspec
Randomized with seed 42644
Puma starting in single mode...
..............******...***...[dots/asterisks/etc represent tests being ran]
Finished in 31.21 seconds (files took 2.99 seconds to load)
68 examples, 0 failures, 28 pending
>
```

Run a local rails server, then point your browser to [localhost:3000/](http://localhost:3000/) to access:
```
> rails s
=> Booting Puma
=> Rails 5.1.4 application starting in development
=> Run `rails server -h` for more startup options
Puma starting in single mode...
* Version 3.11.0 (ruby 2.5.0-p0), codename: Love Song
* Min threads: 5, max threads: 5
* Environment: development
* Listening on tcp://0.0.0.0:3000
Use Ctrl-C to stop

Started GET "/" for 127.0.0.1 at 2018-02-05 17:36:55 -0800
... log lines from app ...
Completed 200 OK in 944ms (Views: 742.9ms | ActiveRecord: 28.1ms)
```

## API Documentation

API documentation is available inside the repository in `doc/api/index.html`.

API endpoint self-documenting tests are available in `spec/acceptance` and use the [RSpec API Doc Generator gem](https://github.com/zipmark/rspec_api_documentation). Note that these tests are meant for documentation purposes only. Please put the actual API integration tests in `spec/requests`.

To regenerate the API documentation, run `rails docs:generate`. Note, regenerating the documentation will always create uncommitted changes, even if you didn't change any of the self-documenting tests.

## Hints/FAQ

If you ran `rails db:seed`, `rails db:setup`, or `rails db:reset`, then you may login with the following seeded credentials:
- Site: MediaPro
  - Username: admin@mediapro.com
  - Password: Default User!
- Site: Demo
  - Username: lmslitedemo@mediapro.com
  - Password: Demonstrable!
  
### How do I get an access token? 
We'll make this process easier, but for the time being please do the following.

1. Open rails console (`rails console` in command line) and do
```
application = Doorkeeper::Application.create!(name: "foo", redirect_uri: "https://www.yourredirecturi.com")
```
2. Make a note of the ID of the newly created applcation and do
```
token = Doorkeeper::AccessToken.create!(application_id: application.id, resource_owner_id: :user_id)
```
where `:user_id` is to be replaced with appropriate values
3. Use the string from `token` field for using it in the tool of your choice like Postman. 
```
> token.token
```
Then you'll get something like

```
=> "eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJhZG1pbkBtZWRpYXByby5jb20iLCJpYXQiOjE1MTg2NDA3MDcsImp0aSI6IjE0ZTdjMTlmLWE5ODgtNDg5ZC1iZTZkLTcwM2M5ODIxNGU4MiIsImdpdmVuX25hbWUiOiJNZWRpYVBybyIsImZhbWlseV9uYW1lIjoiQWRtaW4iLCJlbWFpbCI6ImFkbWluQG1lZGlhcHJvLmNvbSIsImV4cCI6MTUxODY0MzUyN30.eYCaAzmU1vEkQ_q_zotIGSTRSWmfCaH9viUXO2P7zWyDE1Np7g53VH-2SiXnzYOmLgudj06iyFqb0OCuwZLnKppQRBN1Ww9MU9nMm_NXy64qtD0XtJfDvCZftpstg8tAoZdul6PX4eUMMDeN88Hhbx_pV1DeZKSTkE9zWs3lX__zVB5o3jiP6gRo_y9C22a3wX0MpSh3KxsNBQR5jshw9mHCfZjr0Q-82Vdzsmo3A8Mmvter855XgR9MlJ2WXP5B96l8yp-4C3lyHSO1o_fO9ZkDXCcs3NmyDuQ5oHmldyNYE9rZI3g15kKjUBtJM9jrQor9Fzutu1N6rPzMMhH5eg"
```

4. Copy and paste the token (without quotes) into your `access_token` variable for Postman. You can do so by clicking on the gear button at the top right in Postman and then click on Mange Environments. Add a new environment (e.g. local or integration), add variable names (without the double curly braces), and then paste the token string there.




### Troubleshooting Feature Tests
We use Capybara and PhantomJS for feature tests. The following methods are useful for debugging. More to come on feature tests.
* `screenshot_and_open_image`
* `screenshot_and_save_page`
