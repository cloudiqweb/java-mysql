class CommunicationDecorator < Draper::Decorator
  def recipient_names
    [model.users, model.groups].flatten.map(&:name).join(', ')
  end

  def display_subject
    model.subject.empty? ? "no subject" : model.subject
  end
end