class Permission < ApplicationRecord
  belongs_to :action
  has_and_belongs_to_many :roles
end

