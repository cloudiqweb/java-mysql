class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :recoverable, :rememberable,
    :trackable, :validatable, authentication_keys: [:login]

  extend DeviseOverrides

  acts_as_paranoid

  attr_accessor :login

  has_many :groups_users
  has_many :groups, through: :groups_users

  has_many :communications
  has_many :users_roles, dependent: :destroy
  has_many :roles, through: :users_roles

  has_and_belongs_to_many :authorization_groups
  has_and_belongs_to_many :sites
  has_and_belongs_to_many :user_groups

  default_scope { includes(:groups_users, :groups) }

  validates :username, format: {
    with: /\A[a-zA-Z0-9_@\.]*\z/,
    message: "only allows letters, numbers, underscores, periods, and @."
  }, allow_blank: true, uniqueness: true
  validate :must_have_username_or_email

  def must_have_username_or_email
    unless username.present? || email.present?
      errors.add(:email, "or Username must be present")
    end
  end

  def site_uuid
    return selected_site_uuid if selected_site_uuid.present?
    return sites.first.site_uuid if sites.first.present?
    nil
  end

  def login
    @login || self.email || self.username
  end

  def email_required?
    false
  end

  def to_s
    "#{given_name} #{family_name} (#{username})"
  end

  def name
    "#{given_name} #{family_name}"
  end

  # return comma seperated string of all roles for this site
  def roles_title site_id = nil
    users_roles.includes(:role).where(site_id: nil).pluck(:name).join(', ')
  end

  def has_role? role_id, site_id = nil
    users_roles.where(role_id: role_id, site_id: site_id).exists?
  end

  def self.find_for_database_authentication(warden_conditions)
    conditions = warden_conditions.dup
    if login = conditions.delete(:login)
      unscoped.where(conditions.to_h).where(
        ["username = :value OR email = :value", { value: login }]
      ).first
    elsif conditions.has_key?(:username) || conditions.has_key?(:email)
      unscoped.where(conditions.to_hash).first
    end
  end
end

