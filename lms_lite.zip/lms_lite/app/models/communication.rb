class Communication < ApplicationRecord
  acts_as_paranoid
  include Siteable

  belongs_to :user

  has_many :communications_users
  has_many :users, through: :communications_users

  has_many :communications_groups
  has_many :groups, through: :communications_groups

  default_scope { includes(:communications_users,
                           :users,
                           :communications_groups,
                           :groups) }

  def self.for_user(user)
    (
      where(communications_users: { user: user }).all +
      where(communications_groups: { group: user.groups }).all
    ).uniq.sort_by(&:created_at)
  end
end
