class SiteAssociation < ApplicationRecord
  belongs_to :site_relationship, optional: true
  belongs_to :site
  belongs_to :related_site, class_name: "Site", foreign_key: :related_site_id, optional: true
end

