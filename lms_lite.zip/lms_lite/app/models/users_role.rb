class UsersRole < ApplicationRecord
 
  belongs_to :site
  belongs_to :user
  belongs_to :role

  validates_uniqueness_of :user_id, scope: [:role_id, :site_id], on: :create, message: "role already assigned"
end

