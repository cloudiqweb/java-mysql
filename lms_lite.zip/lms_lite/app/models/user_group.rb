class UserGroup < ApplicationRecord
  acts_as_paranoid
  belongs_to :site
  has_and_belongs_to_many :users
  validates :name, presence: true,
    length: { minimum: 3 },
    uniqueness: { scope: :site_id }
end

