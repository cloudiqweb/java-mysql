
class LearningExperiencesGroup < ApplicationRecord
  belongs_to :learning_experience
  belongs_to :group
end
