class LicensedContent < ApplicationRecord
  include Siteable
  belongs_to :content

  delegate :title, :description, :content_type, to: :content
end
