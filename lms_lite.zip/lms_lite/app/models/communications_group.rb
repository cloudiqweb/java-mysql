class CommunicationsGroup < ApplicationRecord
  acts_as_paranoid
  belongs_to :communication
  belongs_to :group
end
