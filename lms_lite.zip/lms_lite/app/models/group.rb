class Group < ApplicationRecord
  acts_as_paranoid
  include Siteable

  has_many :groups_users
  has_many :users, through: :groups_users
end
