class Content < ApplicationRecord
  enum content_type: {
    "Article" => 0,
    "Course"  => 1,
    # "Custom"  => 2,
    "Survey"  => 3,
    "Poster"  => 4,
    "Video"   => 5
  }

  def to_s
    title
  end
end
