class LearningExperience < ApplicationRecord
  acts_as_paranoid
  include Siteable

  has_many :learning_experiences_licensed_contents
  has_many :licensed_contents, through: :learning_experiences_licensed_contents

  has_many :learning_experiences_users
  has_many :users, through: :learning_experiences_users

  has_many :learning_experiences_groups
  has_many :groups, through: :learning_experiences_groups

  enum experience_type: Content.content_types
end
