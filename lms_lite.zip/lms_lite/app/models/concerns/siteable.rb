require 'active_support/concern'

module Siteable
  extend ActiveSupport::Concern

  included do
    belongs_to :site
    validates :site, presence: true
    default_scope { where(site: Site.current_site) }
  end
end
