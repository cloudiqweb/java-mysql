class Role < ApplicationRecord
  has_many                  :users_roles, dependent: :destroy
  has_many :users, through: :users_roles
  has_and_belongs_to_many :authorization_groups
end

