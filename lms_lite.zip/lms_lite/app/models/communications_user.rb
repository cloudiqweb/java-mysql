class CommunicationsUser < ApplicationRecord
  acts_as_paranoid
  belongs_to :communication
  belongs_to :user
end
