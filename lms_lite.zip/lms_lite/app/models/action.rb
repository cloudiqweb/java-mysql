class Action < ApplicationRecord
  has_many :permissions, dependent: :restrict_with_error
end

