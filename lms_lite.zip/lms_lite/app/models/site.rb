class Site < ApplicationRecord
  acts_as_paranoid
  has_many :authorization_groups, dependent: :restrict_with_error
  has_and_belongs_to_many :users
  has_many :site_associations, dependent: :destroy
  has_many :sites, through: :site_associations
  has_many :related_sites,
    through: :site_associations,
    foreign_key: :related_site_id
  has_many :groups
  has_many :learning_experiences
  has_many :licensed_contents

  validates :name, presence: true, uniqueness: { case_sensitive: false }

  before_create :generate_site_uuid

  after_destroy { |record|
    User.where(selected_site_uuid: record.site_uuid)
    .update_all(selected_site_uuid: nil)
  }

  def to_s
    name
  end

  def self.current_site=(site)
    Thread.current[:site] = site
  end

  def self.current_site
    Thread.current[:site]
  end

  private

  def generate_site_uuid
    self.site_uuid = SecureRandom.uuid
  end
end
