class SwitchFormBuilder < ActionView::Helpers::FormBuilder
  def check_box_switch(method, options={}, checked_value="1", unchecked_value="0")
    @template.content_tag(:div, class: "switch") do
      @template.concat @template.check_box(@object_name, method, objectify_options(options), checked_value, unchecked_value)
      @template.concat @template.content_tag(:div, nil, class: "slider")
    end
  end

  def labeled_check_box_switch(label_text, method, options={}, checked_value="1", unchecked_value="0")
    @template.label(@object_name, method) do
      @template.concat label_text
      @template.concat check_box_switch(method, options, checked_value, unchecked_value)
    end
  end
end
