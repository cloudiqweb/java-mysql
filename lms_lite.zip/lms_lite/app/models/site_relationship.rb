class SiteRelationship < ApplicationRecord
  has_one :site_association
end

