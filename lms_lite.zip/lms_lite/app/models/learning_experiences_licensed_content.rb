class LearningExperiencesLicensedContent < ApplicationRecord
  belongs_to :learning_experience
  belongs_to :licensed_content
end
