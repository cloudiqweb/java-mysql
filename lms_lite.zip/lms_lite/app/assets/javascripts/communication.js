var ready;

ready = function() {
  $('#inbox-table').dataTable({
    responsive: true,
    processing: true
  });

  $('#sent-table').dataTable({
    responsive: true,
    processing: true
  });

  $('#send_to_users').select2();
  $('#send_to_groups').select2();
}	

$(document).on('turbolinks:load', ready);