var ready;
ready = function() {
  var _self = this;
  _self.learningTypeFilterHtml = '<div class="learning-type-filter-container"><label>Type:  </label> <select id="learning-type-filter">' +
      '<option value="all">All</option>' +
      '<option value="article">Article</option>' +
      '<option value="course">Course</option>' +
      '<option value="custom">Custom</option>' +
      '<option value="poster">Poster</option>' +
      '<option value="survey">Survey</option>' +
      '<option value="video">Video</option>' +
      '</select></div>';

  _self.contentTypeFilterHtml = '<div class="content-type-filter-container"><label>Type:  </label> <select id="content-type-filter">' +
      '<option value="all">All</option>' +
      '<option value="article">Article</option>' +
      '<option value="course">Course</option>' +
      '<option value="custom">Custom</option>' +
      '<option value="poster">Poster</option>' +
      '<option value="survey">Survey</option>' +
      '<option value="video">Video</option>' +
      '</select></div>';

  $('#learning-experiences-table').dataTable({
    responsive: true,
    processing: true,
    columnDefs: [
      { width: '25%', targets: 0 },
      { width: '60%',
        targets: 1,
        render: function (data, type, row) {
          return data.length > 300 ? data.substr(0, 300) + '...' : data;
        }
      },
      { name: 'learningType', width: '15%', targets: 2 }
    ],
    initComplete: function() {
      var _this = this;
      $(_self.learningTypeFilterHtml).insertBefore('#learning-experiences-table_filter');
      $('#learning-type-filter').select2({
        minimumResultsForSearch: Infinity
      });
      var learning_type_filter = new LearningTypeFilter({
        id: '#learning-type-filter',
        table: _this,
        targetColumnName: 'learningType'
      });
      learning_type_filter.buildFilter();
    }
  });

  $('#learning_experience_experience_type').select2({
    minimumResultsForSearch: Infinity,
    width: '50%'
  });

  $('#learning_experience_type').select2({
    minimumResultsForSearch: Infinity,
    width: '50%'
  });

  $('#contents-table').dataTable({
    responsive: true,
    processing: true
  });

  $('#add-content-table').dataTable({
    responsive: true,
    processing: true,
    columnDefs: [
      { width: '5%', targets: 0 },
      { width: '20%', targets: 1 },
      { width: '60%',
        targets: 2,
        render: function (data, type, row) {
          return data.length > 300 ? data.substr(0, 300) + '...' : data;
        }
      },
      { name: 'contentType',width: '15%', targets: 3 }
    ],
    initComplete: function() {
      var _this = this;
      $(_self.contentTypeFilterHtml).insertBefore('#add-content-table_filter');
      $('#content-type-filter').select2({
        minimumResultsForSearch: Infinity
      });
      var content_type_filter = new ContentTypeFilter({
        id: '#content-type-filter',
        table: _this,
        targetColumnName: 'contentType'
      });
      content_type_filter.buildFilter();
    }
  });

  $('#users-table').dataTable({
    responsive: true,
    processing: true
  });

  $('#add-users-table').dataTable({
    responsive: true,
    processing: true,
    serverSide: true,
    ajax: {
      type: 'POST',
      url: $('#add-users-table').data('source')
    },
    columns: [
      {data: 'checkbox'},
      {data: 'username'},
      {data: 'given_name'},
      {data: 'family_name'},
      {data: 'email'},
      {data: 'role'},
      {data: 'department'}
    ]
  });

  $('#groups-table').dataTable({
    responsive: true,
    processing: true
  });

  $('#add-groups-table').dataTable({
    responsive: true,
    processing: true
  });

  $('#learning-experience-start-at').datetimepicker();
  $('#learning-experience-end-at').datetimepicker();
  $('#learning-experience-expires-at').datetimepicker();

  $('#add-content-modal').on('show.bs.modal', function(e){
    fitModal('#add-content-modal');
  });

  $('#add-users-modal').on('show.bs.modal', function(e){
    fitModal('#add-users-modal');
  });

  $('#add-groups-modal').on('show.bs.modal', function(e){
    fitModal('#add-groups-modal');
  });
}

function fitModal(modalId){
  var winH = $(window).height();
  var selector = modalId + ' .modal-body';
  $(selector).css({'max-height': (winH - 190) + 'px'});
}

$(document).on('turbolinks:load', ready);
