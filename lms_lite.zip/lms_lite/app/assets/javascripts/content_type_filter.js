"use strict";

function ContentTypeFilter(settings){
  this.id = settings.id;
  this.table = settings.table;
  this.targetColumnName = settings.targetColumnName + ":name";
}

ContentTypeFilter.prototype.buildFilter = function(){
  var _this = this;

  $(_this.id).on('select2:select', function(e){
    var searchTerm = e.params.data.id;

    if (searchTerm == 'all') {
      searchTerm = "";
    }

    _this.table.DataTable().column(_this.targetColumnName).search(searchTerm).draw();
  });
}