class Api::V1::UsersController < Api::V1::ApiController
  before_action :set_user, only: [:show, :update, :destroy]
  
  def me
    render json: current_resource_owner.as_json, status: 200
  end

  # GET /api/v1/users/:id
  def show
  	render json: @user.to_json, status: 200
  end

  # POST /api/v1/users
  def create
    @user = User.create!(user_params)
    @user.sites << Site.where(id: params[:site_ids])
    render json: @user.to_json, status: 201
  end

  def update
    @user.update!(user_params)
    head :no_content
  end

  def destroy
    @user.destroy
    head :no_content
  end

  private

    def user_params
      params.permit(:password, :username, :given_name, :family_name, 
        :email,  :department, :middle_name, :comments)
    end

    def set_user
      @user = User.find(params[:id])
    end
end
