class Api::V1::UserGroupsController < Api::V1::ApiController
  before_action :set_user_group, only: [:show, :update, :destroy]

  def index
    json_response(UserGroup.all)
  end

  def create
    @user_group = UserGroup.create!(user_group_params)
    json_response(@user_group, :created)
  end

  def show
    json_response(@user_group)
  end

  def update
    @user_group.update!(user_group_params)
    head :no_content
  end

  def destroy
    @user_group.destroy!
    head :no_content
  end

  private

  def user_group_params
    params.permit(:name, :site)
  end

  def set_user_group
    @user_group = UserGroup.find(params[:id])
  end
end

