class Api::V1::ApiController < ::ActionController::Base
  include Response
  include ApiExceptionHandler

  before_action :doorkeeper_authorize!

  private

  def current_resource_owner
    User.find(doorkeeper_token.resource_owner_id).as_json(methods: :site_uuid) if doorkeeper_token
  end
end

