class Api::V1::RolesController < Api::V1::ApiController
  before_action :set_user, only: [:index, :create, :update, :destroy, :show]
  before_action :set_role, only: [:update, :destroy]

  def index
    json_response({ 'roles': @user.roles_title })
  end
  
  # check if user has role
  # GET /api/v1/users/:id/roles/:role
  def show
    json_response({ 'match': @user.has_role?(params[:id]) })
  end

  # add a role to user
  # PATCH /api/v1/users/:id/roles/:role
  def update
    @user.roles << @role 
    json_response({ 'roles': @user.roles_title })
  end

  # remove user role
  def destroy
    @user.roles.destroy @role if @user.has_role? @role
    json_response({ 'roles': @user.roles_title })
  end

  private
  def set_user
    @user = User.find(params[:user_id])
  end

  def set_role
    @role = Role.find(params[:id])
  end
end
