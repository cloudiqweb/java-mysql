class Api::V1::SitesController < Api::V1::ApiController
  before_action :set_site, only: [:show, :update, :destroy]

  def index
    json_response(Site.all)
  end

  def create
    @site = Site.create!(site_params)
    json_response(@site, :created)
  end

  def show
    json_response(@site)
  end

  def update
    @site.update!(site_params)
    head :no_content
  end

  def destroy
    @site.destroy!
    head :no_content
  end

  private

  def site_params
    params.permit(:name)
  end

  def set_site
    @site = Site.find(params[:id])
  end
end