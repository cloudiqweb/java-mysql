class GamificationsController < ApplicationController
  private

  def current_menu
    @current_menu = "Gamification"
  end
end