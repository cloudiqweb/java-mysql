class CommunicationsController < ApplicationController

  before_action :set_communication, only: [:show]

  def index
    @communications = Communication.for_user(current_user)
    @sent_communications = Communication.where(user: current_user)
  end

  def show
  end

  def new
    @sendable_users = current_site.users.limit(30).to_a << current_user
    @sendable_groups = current_site.groups.limit(30)
    @new_communication = current_user.communications.new
  end


  # POST /contents
  # POST /contents.json
  def create
    @communication = Communication.new(communication_params)
    @communication.user = current_user
    @communication.site = current_site
    @communication.users = User.where(id: params[:send_to_users])
    @communication.groups = Group.where(id: params[:send_to_groups])
    respond_to do |format|
      if @communication.save
        format.html { redirect_to communications_path(anchor: 'sent-tab'), notice: 'Your message has been successfully sent!' }
        format.json { render :show, status: :created, location: @communication }
      else
        format.html { render :new }
        format.json { render json: @communication.errors, status: :unprocessable_entity }
      end
    end
  end


private

  def set_communication
    @communication = Communication.find(params[:id])
  end

  def current_menu
    @current_menu = "Communication"
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def communication_params
    params.require(:communication).permit(:id, :subject, :message)
  end
end
