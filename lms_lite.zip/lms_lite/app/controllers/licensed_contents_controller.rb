class LicensedContentsController < ApplicationController
  before_action :set_licensed_content, only: [:show, :edit, :update, :destroy]

  # GET /licensed_contents
  # GET /licensed_contents.json
  def index
    @licensed_contents = LicensedContent.all
  end

  # GET /licensed_contents/1
  # GET /licensed_contents/1.json
  def show
  end

  # GET /licensed_contents/new
  def new
    @licensed_content = LicensedContent.new
  end

  # GET /licensed_contents/1/edit
  def edit
  end

  # POST /licensed_contents
  # POST /licensed_contents.json
  def create
    @licensed_content = LicensedContent.new(licensed_content_params)

    respond_to do |format|
      if @licensed_content.save
        format.html { redirect_to @licensed_content, notice: 'Licensed content was successfully created.' }
        format.json { render :show, status: :created, location: @licensed_content }
      else
        format.html { render :new }
        format.json { render json: @licensed_content.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /licensed_contents/1
  # PATCH/PUT /licensed_contents/1.json
  def update
    respond_to do |format|
      if @licensed_content.update(licensed_content_params)
        format.html { redirect_to @licensed_content, notice: 'Licensed content was successfully updated.' }
        format.json { render :show, status: :ok, location: @licensed_content }
      else
        format.html { render :edit }
        format.json { render json: @licensed_content.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /licensed_contents/1
  # DELETE /licensed_contents/1.json
  def destroy
    @licensed_content.destroy
    respond_to do |format|
      format.html { redirect_to licensed_contents_url, notice: 'Licensed content was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_licensed_content
      @licensed_content = LicensedContent.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def licensed_content_params
      params.require(:licensed_content).permit(:content_id, :site_id, :inactive_at)
    end
end
