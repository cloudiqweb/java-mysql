class LearningExperiencesController < ApplicationController
  before_action :set_learning_experience, only: [:show, :edit, :update, :destroy, :add_content, :delete_content, :clear_content, :add_users, :delete_users, :clear_users, :add_groups, :delete_groups, :clear_groups]

  # GET /learning_experiences
  # GET /learning_experiences.json
  def index
    @learning_experiences = LearningExperience.all
  end

  # GET /learning_experiences/1
  # GET /learning_experiences/1.json
  def show
    @addable_licensed_contents = LicensedContent.all - @learning_experience.licensed_contents
    @addable_users = User.all - @learning_experience.users
    @addable_groups = Group.includes(:groups_users, :users).all - @learning_experience.groups
  end

  # GET /learning_experiences/new
  def new
    @learning_experience = LearningExperience.new
  end

  # GET /learning_experiences/1/edit
  def edit
  end

  # POST /learning_experiences
  # POST /learning_experiences.json
  def create
    @learning_experience = LearningExperience.new(
      site: Site.current_site,
      title: learning_experience_params[:title],
      description: learning_experience_params[:description],
      active: learning_experience_params[:active],
      experience_type: LearningExperience.experience_types.to_a.map(&:reverse).to_h[learning_experience_params[:experience_type].to_i]
    )

    respond_to do |format|
      if @learning_experience.save
        format.html { redirect_to learning_experience_path(@learning_experience, anchor: 'settings') , notice: 'Learning experience was successfully created.' }
        format.json { render :show, status: :created, location: @learning_experience }
      else
        format.html { render :new }
        format.json { render json: @learning_experience.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /learning_experiences/1
  # PATCH/PUT /learning_experiences/1.json
  def update
    respond_to do |format|
      if @learning_experience.update(learning_experience_attributes)
        format.html { redirect_to learning_experience_path(@learning_experience, anchor: 'settings'), notice: 'Learning experience was successfully updated.' }
        format.json { render :show, status: :ok, location: @learning_experience }
      else
        format.html { render :edit }
        format.json { render json: @learning_experience.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /learning_experiences/1
  # DELETE /learning_experiences/1.json
  def destroy
    @learning_experience.destroy
    respond_to do |format|
      format.html { redirect_to learning_experiences_url, notice: 'Learning experience was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  # POST /learning_experiences/1/add_content
  # POST /learning_experiences/1/add_content.json
  def add_content
    @learning_experience.licensed_contents << LicensedContent.where(id: params[:licensed_contents].map(&:to_i))
    respond_to do |format|
      format.html { redirect_to learning_experience_path(@learning_experience, anchor: 'contents'), notice: 'Content was successfully added.' }
      format.json { head :no_content }
    end
  end

  # POST /learning_experiences/1/delete_content
  # POST /learning_experiences/1/delete_content.json
  def delete_content
    @learning_experience.licensed_contents -= LicensedContent.where(id: params[:licensed_contents].map(&:to_i))
    respond_to do |format|
      format.html { redirect_to learning_experience_path(@learning_experience, anchor: 'contents'), notice: 'Content was successfully removed.' }
      format.json { head :no_content }
    end
  end

  # POST /learning_experiences/1/clear_content
  # POST /learning_experiences/1/clear_content.json
  def clear_content
    @learning_experience.licensed_contents = []
    respond_to do |format|
      format.html { redirect_to learning_experience_path(@learning_experience, anchor: 'contents'), notice: 'All content was successfully removed.' }
      format.json { head :no_content }
    end
  end

  # POST /learning_experiences/1/add_users
  # POST /learning_experiences/1/add_users.json
  def add_users
    @learning_experience.users << User.where(id: params[:users].map(&:to_i))
    respond_to do |format|
      format.html { redirect_to learning_experience_path(@learning_experience, anchor: 'users'), notice: 'Users were successfully added.' }
      format.json { head :no_content }
    end
  end

  # POST /learning_experiences/1/delete_users
  # POST /learning_experiences/1/delete_users.json
  def delete_users
    @learning_experience.users -= User.where(id: params[:users].map(&:to_i))
    respond_to do |format|
      format.html { redirect_to learning_experience_path(@learning_experience, anchor: 'users'), notice: 'Users were successfully removed.' }
      format.json { head :no_content }
    end
  end

  # POST /learning_experiences/1/clear_users
  # POST /learning_experiences/1/clear_users.json
  def clear_users
    @learning_experience.users = []
    respond_to do |format|
      format.html { redirect_to learning_experience_path(@learning_experience, anchor: 'users'), notice: 'All users were successfully removed.' }
      format.json { head :no_content }
    end
  end

  # POST /learning_experiences/1/add_groups
  # POST /learning_experiences/1/add_groups.json
  def add_groups
    @learning_experience.groups << Group.where(id: params[:groups].map(&:to_i))
    respond_to do |format|
      format.html { redirect_to learning_experience_path(@learning_experience, anchor: 'groups'), notice: 'Groups were successfully added.' }
      format.json { head :no_content }
    end
  end

  # POST /learning_experiences/1/delete_groups
  # POST /learning_experiences/1/delete_groups.json
  def delete_groups
    @learning_experience.groups -= Group.where(id: params[:groups].map(&:to_i))
    respond_to do |format|
      format.html { redirect_to learning_experience_path(@learning_experience, anchor: 'groups'), notice: 'Groups were successfully removed.' }
      format.json { head :no_content }
    end
  end

  # POST /learning_experiences/1/clear_groups
  # POST /learning_experiences/1/clear_groups.json
  def clear_groups
    @learning_experience.groups = []
    respond_to do |format|
      format.html { redirect_to learning_experience_path(@learning_experience, anchor: 'groups'), notice: 'All groups were successfully removed.' }
      format.json { head :no_content }
    end
  end

  def datatables_addable_users_list
    respond_to do |format|
      format.json { render json: ::UsersDataForListDatatable.new(view_context) }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_learning_experience
      @learning_experience = LearningExperience.includes(:users, :groups).find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def learning_experience_params
      params.require(:learning_experience).permit(:title, :description, :active, :experience_type, :force_linear, :start_at, :end_at, :access_expires_at, :ratable, :offers_completion_certificate, :mandatory, add_users: [], add_groups: [])
    end

    def current_menu
      @current_menu = "Content Library"
    end

    def learning_experience_attributes
      @learning_experience_attributes ||= learning_experience_params.merge({
        experience_type: LearningExperience.experience_types.to_a.map(&:reverse).to_h[learning_experience_params[:experience_type].to_i],
        start_at: Chronic.parse(learning_experience_params[:start_at]),
        end_at: Chronic.parse(learning_experience_params[:end_at])
      }).to_h
    end
end
