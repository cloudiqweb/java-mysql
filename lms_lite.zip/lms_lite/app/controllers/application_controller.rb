class ApplicationController < ActionController::Base
  before_action :authenticate_user!
  before_action :configure_permitted_parameters, if: :devise_controller?

  protect_from_forgery with: :exception

  before_action :current_menu
  around_action :scope_current_site

  helper_method :current_site

  protected

  def configure_permitted_parameters
    added_attrs = [
      :username, :email, :password, :password_confirmation, :remember_me
    ]
    devise_parameter_sanitizer.permit :account_update, keys: added_attrs
  end

  private

    def current_menu
      controller_name
    end

    def current_site
      Site.current_site
    end

    def scope_current_site
      Site.current_site = current_user&.sites&.where(site_uuid: current_user&.selected_site_uuid)&.first
      yield
    ensure
      Site.current_site = nil
    end
end
