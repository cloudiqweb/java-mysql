class HomeController < ApplicationController

  private

  def current_menu
    @current_menu = "Home"
  end
end