   class ReportsController < ApplicationController

     private

     def current_menu
       @current_menu = "Reports"
     end
   end