class PagesController < ApplicationController
  def account
  end
end
