class Identity::ApiController < ActionController::API

  require 'library-arl'
  require 'json'

  include Rest::Response
  include Authentication::SecureControllerHelper

  def configuration
    configuration = SecurityConfiguration.new
    configuration.authenticationResource = Rails.configuration.security['authentication_resource']
    configuration.origin                 = Rails.configuration.security['frontend_origin']

    response = HalResponse.new
    response._payload = configuration
    respond(response)
  end

  def authenticate
    credentials = JSON.parse(request.body.read)
    username   = credentials['username']
    password = credentials['password']
    context = Authentication::SecurityContext.new

    # TODO Replace this with real database calls

    status = 401
    if username == 'glm'
      manager = Authentication::TokenManager.new
      subject = Authentication::Subject.new
      subject.username = username
      subject.given_name = 'Gary'
      subject.family_name = 'Murphy'
      subject.email = 'glm@hilbertinc.com'
      subject.site_uuid = '38a507b2-a72f-4feb-ba9c-1fce0de70272'
      token = manager.generate_token subject

      context.subject = subject
      context.encoded_token = token
      context.valid! true
      status = 200
    end
    render status: status, json: Rest::HalResponse.new(context)
  end

  def validate_token
    token = JSON.parse(request.body.read)["token"]
    context = Authentication::SecurityContext.new
    status = 200
    begin
      response = Rest::HalResponse.new
      if token
        manager = Authentication::TokenManager.new
        decoded = manager.decode token
        subject = manager.to_subject decoded
        context.subject = subject
        context.encoded_token   = token
        context.refreshed_token = manager.refresh decoded
        context.valid! true
      end
    rescue JWT::DecodeError
      response._error = Rest::Error.new 401, 'The token was expired or not valid'
      status = 401
      context.valid! false
    end
    response._payload = context
    render status: status, json: response
  end
end

