class PlansController < ApplicationController
  before_action :current_menu

  private

  def current_menu
    @current_menu = "Plan"
  end
end