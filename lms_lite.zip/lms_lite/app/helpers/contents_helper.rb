module ContentsHelper
end
