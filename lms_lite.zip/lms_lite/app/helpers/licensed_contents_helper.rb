module LicensedContentsHelper
end
