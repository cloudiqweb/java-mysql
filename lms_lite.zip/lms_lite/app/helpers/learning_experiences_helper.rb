module LearningExperiencesHelper
  def status_glyph(learning_experience)
    if learning_experience.active?
      %Q{<i class="fa fa-circle learning-experience-active"></i><span> Active</span>}.html_safe
    else
      %Q{<i class="fa fa-circle learning-experience-inactive"></i><span> Inactive</span>}.html_safe
    end
  end
end
