class UsersDataForListDatatable < AjaxDatatablesRails::Base

  def view_columns
    @view_columns ||= {
      checkbox: { source: 'User.id', searchable: false, orderable: false },
      username: { source: 'User.username', cond: :like, searchable: true, orderable: true },
      given_name: { source: 'User.given_name', cond: :like, searchable: true, orderable: true },
      family_name: { source: 'User.family_name', cond: :like, searchable: true, orderable: true },
      email: { source: 'User.email', cond: :like, searchable: true, orderable: true },
      role: { source: 'User.roles_title', searchable: false, orderable: false },
      department: { source: 'User.department', searchable: true, orderable: true }
    }
  end

  private

  def data
    records.map do |user|
      {
        checkbox: @view.check_box_tag("users[]", user.id, nil),
        username: @view.content_tag(:b, user.username),
        given_name: user.given_name,
        family_name: user.family_name,
        email: user.email,
        role: user.roles_title,
        department: user.department
      }
    end
  end

  def get_raw_records
    @view.current_site.users
  end
end
