class AddNullConstraintToLearningExperience < ActiveRecord::Migration[5.1]
  def change
    change_column :learning_experiences, :offers_completion_certificate, :boolean, null: false, default: true
  end
end
