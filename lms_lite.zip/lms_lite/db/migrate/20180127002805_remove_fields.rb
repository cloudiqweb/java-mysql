class RemoveFields < ActiveRecord::Migration[5.1]
  def change
    remove_column :learning_experiences, :in_learner_library, :boolean, null: false, default: true
    remove_column :learning_experiences, :inactive_at, :datetime

    remove_column :licensed_contents, :title, :string
    remove_column :licensed_contents, :description, :text
    remove_column :licensed_contents, :active, :boolean, null: false, default: false
    remove_column :licensed_contents, :in_learner_library, :boolean, null: false, default: true
    remove_column :licensed_contents, :force_linear, :boolean, null: false, default: true
    remove_column :licensed_contents, :start_at, :datetime
    remove_column :licensed_contents, :end_at, :datetime
    remove_column :licensed_contents, :access_expires_at, :datetime
    remove_column :licensed_contents, :ratable, :boolean, null: false, default: true
    remove_column :licensed_contents, :offers_completion_certificate, :boolean, null: false, default: true
  end
end
