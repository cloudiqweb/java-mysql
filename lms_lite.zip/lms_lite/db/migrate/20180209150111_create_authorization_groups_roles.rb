class CreateAuthorizationGroupsRoles < ActiveRecord::Migration[5.1]
  def change
    create_join_table :authorization_groups, :roles do |t|
      t.index [:authorization_group_id, :role_id], name: "index_auth_groups_roles_on_auth_group_id_and_role_id"
    end
    add_foreign_key :authorization_groups_roles, :authorization_groups
    add_foreign_key :authorization_groups_roles, :roles
  end
end

