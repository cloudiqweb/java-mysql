class CreateLicensedContents < ActiveRecord::Migration[5.1]
  def change
    create_table :licensed_contents do |t|
      t.references :content, foreign_key: true
      t.string :title
      t.text :description
      t.boolean :active, null: false, default: false
      t.boolean :in_learner_library, null: false, default: true
      t.datetime :inactive_at
      t.boolean :force_linear, null: false, default: true
      t.datetime :start_at
      t.datetime :end_at
      t.datetime :access_expires_at
      t.boolean :ratable, null: false, default: true
      t.boolean :offers_completion_certificate, null: false, default: true
      t.datetime :deleted_at

      t.timestamps
    end
    add_index :licensed_contents, :deleted_at
  end
end
