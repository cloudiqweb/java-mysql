class CreateLearningExperiences < ActiveRecord::Migration[5.1]
  def change
    create_table :learning_experiences do |t|
      t.string :title
      t.text :description
      t.boolean :active, null: false, default: false
      t.integer :experience_type
      t.boolean :in_learner_library, null: false, default: true
      t.datetime :inactive_at
      t.boolean :force_linear, null: false, default: false
      t.datetime :start_at
      t.datetime :end_at
      t.datetime :access_expires_at
      t.boolean :ratable, null: false, default: true
      t.boolean :offers_completion_certificate, default: true
      t.boolean :required, null: false, default: false

      t.timestamps
    end
  end
end
