class AddDepartmentToUsers < ActiveRecord::Migration[5.1]
  def change
    add_column :users, :department, :citext
    
    remove_column :users, :department_id, :integer

    drop_table :departments, force: :cascade
    drop_table :departments_users, force: :cascade
    drop_table :communications_departments, force: :cascade
  end
end
