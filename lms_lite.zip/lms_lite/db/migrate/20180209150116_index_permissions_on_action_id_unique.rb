class IndexPermissionsOnActionIdUnique < ActiveRecord::Migration[5.1]
  def change
    remove_index :permissions, :action_id
    add_index :permissions, [:action_id, :classification], unique: true
  end
end
