class RemoveSitesFromRoles < ActiveRecord::Migration[5.1]
  def change
    remove_column :roles, :site_id
  end
end
