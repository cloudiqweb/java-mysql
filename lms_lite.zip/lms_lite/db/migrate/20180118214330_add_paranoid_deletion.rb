class AddParanoidDeletion < ActiveRecord::Migration[5.1]
  def change
    add_column :learning_experiences, :deleted_at, :datetime, default: nil
    add_index :learning_experiences, :deleted_at

    add_column :users, :deleted_at, :datetime, default: nil
    add_index :users, :deleted_at

    add_column :groups, :deleted_at, :datetime, default: nil
    add_index :groups, :deleted_at

    add_column :departments, :deleted_at, :datetime, default: nil
    add_index :departments, :deleted_at
  end
end
