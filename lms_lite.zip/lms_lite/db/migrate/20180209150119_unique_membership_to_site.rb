
# The Rails has and belongs to many doesn't put a unique constraint on the association table as it should, and I don't
# think there is a non-SQL way to due that, since there isn't a class for the association table
class UniqueMembershipToSite < ActiveRecord::Migration[5.1]
  def up
    execute <<-SQL
      alter table sites_users drop constraint if exists unique_user_site_membership; -- Make it idempotent
      alter table sites_users add constraint unique_user_site_membership unique(site_id, user_id);
    SQL
  end

  def down
    execute <<-SQL
      alter table sites_users drop constraint if exists unique_user_site_membership;
    SQL
  end
end
