class AddDeletedAtToSites < ActiveRecord::Migration[5.1]
  def change
    add_column :sites, :deleted_at, :datetime, default: nil
    add_index :sites, :deleted_at
  end
end
