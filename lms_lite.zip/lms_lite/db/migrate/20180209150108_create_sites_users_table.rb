class CreateSitesUsersTable < ActiveRecord::Migration[5.1]
  def change
    create_join_table :sites, :users do |t|
      t.index [:site_id, :user_id]
    end
    add_foreign_key :sites_users, :sites
    add_foreign_key :sites_users, :users
  end
end

