class RenameRequiredToMandatoryForLearningExperiences < ActiveRecord::Migration[5.1]
  def change
    rename_column :learning_experiences, :required, :mandatory
  end
end
