class CreateAttachedLearningExperiences < ActiveRecord::Migration[5.1]
  def change
    create_table :attached_learning_experiences do |t|
      t.integer :learning_experience_id
      t.integer :attached_to_learning_experience_id
      t.integer :order

      t.timestamps
    end
  end
end
