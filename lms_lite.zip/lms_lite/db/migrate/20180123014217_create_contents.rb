class CreateContents < ActiveRecord::Migration[5.1]
  def change
    create_table :contents do |t|
      t.string :title
      t.integer :type
      t.text :description
      t.datetime :deleted_at

      t.timestamps
    end
    add_index :contents, :type
    add_index :contents, :deleted_at
  end
end
