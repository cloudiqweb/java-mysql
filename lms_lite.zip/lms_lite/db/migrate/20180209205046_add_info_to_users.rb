class AddInfoToUsers < ActiveRecord::Migration[5.1]
  def change
    enable_extension :citext
    change_column :users, :email, :citext
    change_column :users, :username, :citext
    rename_column :users, :first_name, :given_name
    rename_column :users, :last_name, :family_name
    add_column :users, :identity_issuer, :string
    add_column :users, :middle_name, :string
    add_column :users, :comments, :text
    add_column :users, :password_changed_at, :timestamp
    add_column :users, :last_interaction_at, :timestamp
    add_column :users, :selected_site_uuid, :string
  end
end

