class CreateLearningExperiencesLicensedContents < ActiveRecord::Migration[5.1]
  def change
    create_table :learning_experiences_licensed_contents do |t|
      t.references :learning_experience, foreign_key: true, index: { name: 'index_lrn_xp_content_on_exp_id' }
      t.references :licensed_content, foreign_key: true, index: { name: 'index_lrn_xp_content_on_lic_cont_id' }
      t.integer :order

      t.timestamps
    end
  end
end
