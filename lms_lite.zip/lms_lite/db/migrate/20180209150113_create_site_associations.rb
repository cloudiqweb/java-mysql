class CreateSiteAssociations < ActiveRecord::Migration[5.1]
  def change
    create_table :site_associations do |t|
      t.references :site_relationship, foreign_key: true
      t.integer :related_site_id, foreign_key: true
      t.references :site, foreign_key: true

      t.timestamps
    end
    add_index(:site_associations, [:related_site_id, :site_id], :unique => true)
    add_index(:site_associations, [:site_id, :related_site_id], :unique => true)
    add_foreign_key :site_associations, :sites, column: :related_site_id
  end
end

