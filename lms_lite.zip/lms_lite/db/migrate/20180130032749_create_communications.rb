class CreateCommunications < ActiveRecord::Migration[5.1]
  def change
    create_table :communications do |t|
      t.references :tenant, foreign_key: true
      t.references :user, foreign_key: true
      t.string :subject
      t.text :message

      t.datetime :deleted_at
      t.timestamps
    end

    create_table :communications_users do |t|
      t.references :tenant, foreign_key: true
      t.references :communication, foreign_key: true
      t.references :user, foreign_key: true

      t.datetime :deleted_at
      t.timestamps
    end

    create_table :communications_groups do |t|
      t.references :tenant, foreign_key: true
      t.references :communication, foreign_key: true
      t.references :group, foreign_key: true

      t.datetime :deleted_at
      t.timestamps
    end

    create_table :communications_departments do |t|
      t.references :tenant, foreign_key: true
      t.references :communication, foreign_key: true
      t.references :department, foreign_key: true

      t.datetime :deleted_at
      t.timestamps
    end
  end
end
