class CreateUserGroups < ActiveRecord::Migration[5.1]
  def change
    create_table :user_groups do |t|
      t.string :name
      t.references :site, foreign_key: true
      t.datetime :deleted_at

      t.timestamps
    end
  end
end
