class ChangeUuidColumnName < ActiveRecord::Migration[5.1]
  def change
    rename_column :sites, :uuid, :site_uuid
    change_column :sites, :site_uuid, :string, null: false
  end
end

