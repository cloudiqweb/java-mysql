class DestroyTenants < ActiveRecord::Migration[5.1]
  def change
    drop_table :tenants do |t|
      t.string :name

      t.timestamps
    end
  end
end
