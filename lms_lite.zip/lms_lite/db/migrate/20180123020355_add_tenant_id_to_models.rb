class AddTenantIdToModels < ActiveRecord::Migration[5.1]
  def change
    add_reference :departments, :tenant, null: false
    add_reference :groups, :tenant, null: false
    add_reference :learning_experiences, :tenant, null: false
    add_reference :licensed_contents, :tenant, null: false
    add_reference :users, :tenant, null: false
  end
end
