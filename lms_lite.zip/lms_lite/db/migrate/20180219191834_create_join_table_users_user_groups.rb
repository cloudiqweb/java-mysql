class CreateJoinTableUsersUserGroups < ActiveRecord::Migration[5.1]
  def change
    create_join_table :users, :user_groups do |t|
      t.index :user_id
      t.index :user_group_id
    end
  end
end

