class CreateAuthorizationGroupsUsers < ActiveRecord::Migration[5.1]
  def change
    create_join_table :authorization_groups, :users do |t|
      t.index [:authorization_group_id, :user_id], name: "index_auth_groups_users_on_auth_group_id_and_user_id"
    end
    add_foreign_key :authorization_groups_users, :authorization_groups
    add_foreign_key :authorization_groups_users, :users
  end
end

