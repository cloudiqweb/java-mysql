class RemoveUserRoleId < ActiveRecord::Migration[5.1]
  def change
    remove_column :users, :role_id
    drop_join_table :roles, :users

    create_table :users_roles, :id => false do |t|
      t.references :user, index: true, foreign_key: true, null: false
      t.references :site, index: true, foreign_key: true, null: true
      t.references :role, index: true, foreign_key: true, null: false
    end

    add_index :users_roles, [:user_id,:site_id,:role_id], unique: true
  end
end
