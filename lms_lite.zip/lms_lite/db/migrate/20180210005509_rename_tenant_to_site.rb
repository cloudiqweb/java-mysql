class RenameTenantToSite < ActiveRecord::Migration[5.1]
  def change
    remove_reference :communications, :tenant
    remove_reference :communications_groups, :tenant
    remove_reference :communications_users, :tenant
    remove_reference :groups, :tenant
    remove_reference :learning_experiences, :tenant
    remove_reference :licensed_contents, :tenant
    remove_reference :users, :tenant
    add_reference :communications, :site
    add_reference :communications_groups, :site
    add_reference :communications_users, :site
    add_reference :groups, :site
    add_reference :learning_experiences, :site
    add_reference :licensed_contents, :site
  end
end
