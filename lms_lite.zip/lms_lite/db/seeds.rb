site = Site.unscoped.find_or_initialize_by(
  name: 'MediaPro'
)
unless site.persisted?
  puts '[Seeds] Creating MediaPro site'
  site.site_uuid = SecureRandom.uuid
  site.save!(validate: false)
end

puts '[Seeds] Adding user roles'
roles = %w"MP\ Admin Content\ Manager Partner Account\ Owner Site\ Admin Group\ Admin Reporter Learner"
roles.each{|role| Role.create(name: role)}

Site.current_site = site

default_admin = User.unscoped.find_or_initialize_by(
  username: 'mediapro',
  given_name: 'MediaPro',
  family_name: 'Admin',
  email: 'admin@mediapro.com',
  department: 'engineering'
)

default_admin.roles << Role.first

unless default_admin.persisted?
  default_admin.password = default_admin.password_confirmation = 'Default User!'
  default_admin.sites << site
  default_admin.selected_site_uuid = site.site_uuid
  puts "[Seeds] Creating #{default_admin.email} user on #{site.name} site with password \"#{default_admin.password}\""
  default_admin.save!(validate: false)
end

unless Content.any?
  count = 100
  puts "[Seeds] Creating #{count} units of content"
  count.times do
    c = Content.create(
      title: Faker::Lorem.words(4).map(&:titleize).join(' '),
      description: Faker::Lorem.paragraph,
      content_type: Content.content_types.to_a.sample.second
    )
    LicensedContent.create(
      content: c,
      site: site
    )
  end
end

demo_site = Site.unscoped.find_or_initialize_by(
  name: 'Demo'
)
unless demo_site.persisted?
  puts '[Seeds] Creating Demo site'
  demo_site.site_uuid = SecureRandom.uuid
  demo_site.save!(validate: false)

  Content.all.each do |c|
    LicensedContent.create(
      content: c,
      site: demo_site
    )
  end
end

Site.current_site = demo_site

demo_admin = User.unscoped.find_or_initialize_by(
  username: 'demo',
  given_name: 'Demo',
  family_name: 'Demo',
  email: 'lmslitedemo@mediapro.com',
  department: 'demo department'
)
demo_admin.roles << Role.find_by(name: "Site Admin")

unless demo_admin.persisted?
  demo_admin.sites << demo_site
  demo_admin.selected_site_uuid = demo_site.site_uuid
  demo_admin.password = demo_admin.password_confirmation = 'Demonstrable!'
  puts "[Seeds] Creating #{demo_admin.email} user on #{demo_site.name} site"
  demo_admin.save!(validate: false)
end

# Set up sample data for demo/developemnt/etc.
demo_users = []
learner_role = Role.find_by(name: "Learner")
unless demo_site.users.count > 1
  count = 105
  puts "[Seeds] Creating #{count} demo users for #{demo_site.name} site"
  count.times do
    demo_user = FactoryBot.create(
      :user,
      sites: [demo_site],
      selected_site_uuid: demo_site.site_uuid,
      department: Faker::Team.creature
    )
    demo_user.roles << learner_role
  end
end

demo_groups = []
unless demo_site.groups.count > 0
  count = 20
  puts "[Seeds] Creating #{count} demo groups for #{demo_site.name}"
  count.times do
    demo_groups << Group.create(
      site: demo_site,
      name: Faker::Company.profession
    )
  end
end

demo_learning_experiences = []
unless demo_site.learning_experiences.count > 0
  count = 5
  puts "[Seeds] Creating #{count} demo learning experiences for #{demo_site.name}"
  count.times do
    demo_learning_experiences << LearningExperience.create(
      site: demo_site,
      title: Faker::Lorem.words(4).map(&:titleize).join(' '),
      description: Faker::Lorem.paragraph,
      experience_type: LearningExperience.experience_types.to_a.sample.second
    )
  end
end

if demo_users.any? && demo_groups.any?
  puts '[Seeds] Adding demo users to demo groups'

  demo_users.each do |user|
    user.groups << demo_groups.sample
  end
end

if demo_learning_experiences.any?
  puts '[Seeds] Adding demo users and demo groups to demo learning experiences'

  demo_learning_experiences.sample(20).each do |learning_experience|
    learning_experience.groups <<  demo_groups.sample([1,2,3,4,5].sample)
  end

  demo_learning_experiences.sample(20).each do |learning_experience|
    learning_experience.users <<  demo_users.sample([7, 70, 700].sample)
  end
end

demo_communications = []
unless Communication.for_user(demo_admin).count > 1
  puts '[Seeds] Adding 20 demo communications for demo admin'

  20.times do |i|
    demo_communications << Communication.create(
      site: demo_site,
      user: demo_admin,
      users: demo_users.sample(10),
      groups: demo_groups.sample(3),
      subject: Faker::Job.key_skill,
      message: Faker::Lorem.paragraph
    )
  end
end
