# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20180223232249) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"
  enable_extension "citext"

  create_table "actions", force: :cascade do |t|
    t.string "name"
    t.string "description"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "authorization_groups", force: :cascade do |t|
    t.string "name"
    t.bigint "site_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["site_id"], name: "index_authorization_groups_on_site_id"
  end

  create_table "authorization_groups_roles", id: false, force: :cascade do |t|
    t.bigint "authorization_group_id", null: false
    t.bigint "role_id", null: false
    t.index ["authorization_group_id", "role_id"], name: "index_auth_groups_roles_on_auth_group_id_and_role_id"
  end

  create_table "authorization_groups_users", id: false, force: :cascade do |t|
    t.bigint "authorization_group_id", null: false
    t.bigint "user_id", null: false
    t.index ["authorization_group_id", "user_id"], name: "index_auth_groups_users_on_auth_group_id_and_user_id"
  end

  create_table "communications", force: :cascade do |t|
    t.bigint "user_id"
    t.string "subject"
    t.text "message"
    t.datetime "deleted_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "site_id"
    t.index ["site_id"], name: "index_communications_on_site_id"
    t.index ["user_id"], name: "index_communications_on_user_id"
  end

  create_table "communications_groups", force: :cascade do |t|
    t.bigint "communication_id"
    t.bigint "group_id"
    t.datetime "deleted_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "site_id"
    t.index ["communication_id"], name: "index_communications_groups_on_communication_id"
    t.index ["group_id"], name: "index_communications_groups_on_group_id"
    t.index ["site_id"], name: "index_communications_groups_on_site_id"
  end

  create_table "communications_users", force: :cascade do |t|
    t.bigint "communication_id"
    t.bigint "user_id"
    t.datetime "deleted_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "site_id"
    t.index ["communication_id"], name: "index_communications_users_on_communication_id"
    t.index ["site_id"], name: "index_communications_users_on_site_id"
    t.index ["user_id"], name: "index_communications_users_on_user_id"
  end

  create_table "contents", force: :cascade do |t|
    t.string "title"
    t.integer "content_type"
    t.text "description"
    t.datetime "deleted_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["content_type"], name: "index_contents_on_content_type"
    t.index ["deleted_at"], name: "index_contents_on_deleted_at"
  end

  create_table "groups", force: :cascade do |t|
    t.string "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.datetime "deleted_at"
    t.bigint "site_id"
    t.index ["deleted_at"], name: "index_groups_on_deleted_at"
    t.index ["site_id"], name: "index_groups_on_site_id"
  end

  create_table "groups_users", force: :cascade do |t|
    t.bigint "group_id"
    t.bigint "user_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["group_id"], name: "index_groups_users_on_group_id"
    t.index ["user_id"], name: "index_groups_users_on_user_id"
  end

  create_table "learning_experiences", force: :cascade do |t|
    t.string "title"
    t.text "description"
    t.boolean "active", default: false, null: false
    t.integer "experience_type"
    t.boolean "force_linear", default: false, null: false
    t.datetime "start_at"
    t.datetime "end_at"
    t.datetime "access_expires_at"
    t.boolean "ratable", default: true, null: false
    t.boolean "offers_completion_certificate", default: true, null: false
    t.boolean "mandatory", default: false, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.datetime "deleted_at"
    t.bigint "site_id"
    t.index ["deleted_at"], name: "index_learning_experiences_on_deleted_at"
    t.index ["site_id"], name: "index_learning_experiences_on_site_id"
  end

  create_table "learning_experiences_groups", force: :cascade do |t|
    t.bigint "learning_experience_id"
    t.bigint "group_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["group_id"], name: "index_learning_experiences_groups_on_group_id"
    t.index ["learning_experience_id"], name: "index_learning_experiences_groups_on_learning_experience_id"
  end

  create_table "learning_experiences_licensed_contents", force: :cascade do |t|
    t.bigint "learning_experience_id"
    t.bigint "licensed_content_id"
    t.integer "order"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["learning_experience_id"], name: "index_lrn_xp_content_on_exp_id"
    t.index ["licensed_content_id"], name: "index_lrn_xp_content_on_lic_cont_id"
  end

  create_table "learning_experiences_users", force: :cascade do |t|
    t.bigint "learning_experience_id"
    t.bigint "user_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["learning_experience_id"], name: "index_learning_experiences_users_on_learning_experience_id"
    t.index ["user_id"], name: "index_learning_experiences_users_on_user_id"
  end

  create_table "licensed_contents", force: :cascade do |t|
    t.bigint "content_id"
    t.datetime "inactive_at"
    t.datetime "deleted_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "site_id"
    t.index ["content_id"], name: "index_licensed_contents_on_content_id"
    t.index ["deleted_at"], name: "index_licensed_contents_on_deleted_at"
    t.index ["site_id"], name: "index_licensed_contents_on_site_id"
  end

  create_table "oauth_access_grants", id: :serial, force: :cascade do |t|
    t.integer "resource_owner_id", null: false
    t.integer "application_id", null: false
    t.string "token", null: false
    t.integer "expires_in", null: false
    t.text "redirect_uri", null: false
    t.datetime "created_at", null: false
    t.datetime "revoked_at"
    t.string "scopes"
    t.index ["application_id"], name: "index_oauth_access_grants_on_application_id"
    t.index ["token"], name: "index_oauth_access_grants_on_token", unique: true
  end

  create_table "oauth_access_tokens", id: :serial, force: :cascade do |t|
    t.integer "resource_owner_id"
    t.integer "application_id"
    t.string "token", null: false
    t.string "refresh_token"
    t.integer "expires_in"
    t.datetime "revoked_at"
    t.datetime "created_at", null: false
    t.string "scopes"
    t.string "previous_refresh_token", default: "", null: false
    t.index ["application_id"], name: "index_oauth_access_tokens_on_application_id"
    t.index ["refresh_token"], name: "index_oauth_access_tokens_on_refresh_token", unique: true
    t.index ["resource_owner_id"], name: "index_oauth_access_tokens_on_resource_owner_id"
    t.index ["token"], name: "index_oauth_access_tokens_on_token", unique: true
  end

  create_table "oauth_applications", id: :serial, force: :cascade do |t|
    t.string "name", null: false
    t.string "uid", null: false
    t.string "secret", null: false
    t.text "redirect_uri", null: false
    t.string "scopes", default: "", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["uid"], name: "index_oauth_applications_on_uid", unique: true
  end

  create_table "oauth_openid_requests", id: :serial, force: :cascade do |t|
    t.integer "access_grant_id", null: false
    t.string "nonce", null: false
  end

  create_table "permissions", force: :cascade do |t|
    t.bigint "action_id"
    t.string "classification"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["action_id", "classification"], name: "index_permissions_on_action_id_and_classification", unique: true
  end

  create_table "permissions_roles", id: false, force: :cascade do |t|
    t.bigint "permission_id", null: false
    t.bigint "role_id", null: false
    t.index ["permission_id", "role_id"], name: "index_permissions_roles_on_permission_id_and_role_id"
  end

  create_table "roles", force: :cascade do |t|
    t.string "description"
    t.string "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "site_associations", force: :cascade do |t|
    t.bigint "site_relationship_id"
    t.integer "related_site_id"
    t.bigint "site_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["related_site_id", "site_id"], name: "index_site_associations_on_related_site_id_and_site_id", unique: true
    t.index ["site_id", "related_site_id"], name: "index_site_associations_on_site_id_and_related_site_id", unique: true
    t.index ["site_id"], name: "index_site_associations_on_site_id"
    t.index ["site_relationship_id"], name: "index_site_associations_on_site_relationship_id"
  end

  create_table "site_relationships", force: :cascade do |t|
    t.string "name"
    t.string "description"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "sites", force: :cascade do |t|
    t.string "site_uuid", null: false
    t.string "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.datetime "deleted_at"
    t.index ["deleted_at"], name: "index_sites_on_deleted_at"
  end

  create_table "sites_users", id: false, force: :cascade do |t|
    t.bigint "site_id", null: false
    t.bigint "user_id", null: false
    t.index ["site_id", "user_id"], name: "index_sites_users_on_site_id_and_user_id"
    t.index ["site_id", "user_id"], name: "unique_user_site_membership", unique: true
  end

  create_table "user_groups", force: :cascade do |t|
    t.string "name"
    t.bigint "site_id"
    t.datetime "deleted_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["site_id"], name: "index_user_groups_on_site_id"
  end

  create_table "user_groups_users", id: false, force: :cascade do |t|
    t.bigint "user_id", null: false
    t.bigint "user_group_id", null: false
    t.index ["user_group_id"], name: "index_user_groups_users_on_user_group_id"
    t.index ["user_id"], name: "index_user_groups_users_on_user_id"
  end

  create_table "users", force: :cascade do |t|
    t.citext "username"
    t.string "given_name"
    t.string "family_name"
    t.citext "email"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.datetime "deleted_at"
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer "sign_in_count", default: 0, null: false
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.inet "current_sign_in_ip"
    t.inet "last_sign_in_ip"
    t.string "identity_issuer"
    t.string "middle_name"
    t.text "comments"
    t.datetime "password_changed_at"
    t.datetime "last_interaction_at"
    t.string "selected_site_uuid"
    t.citext "department"
    t.index ["deleted_at"], name: "index_users_on_deleted_at"
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true
  end

  create_table "users_roles", id: false, force: :cascade do |t|
    t.bigint "user_id", null: false
    t.bigint "site_id"
    t.bigint "role_id", null: false
    t.index ["role_id"], name: "index_users_roles_on_role_id"
    t.index ["site_id"], name: "index_users_roles_on_site_id"
    t.index ["user_id"], name: "index_users_roles_on_user_id"
  end

  add_foreign_key "authorization_groups", "sites"
  add_foreign_key "authorization_groups_roles", "authorization_groups"
  add_foreign_key "authorization_groups_roles", "roles"
  add_foreign_key "authorization_groups_users", "authorization_groups"
  add_foreign_key "authorization_groups_users", "users"
  add_foreign_key "communications", "users"
  add_foreign_key "communications_groups", "communications"
  add_foreign_key "communications_groups", "groups"
  add_foreign_key "communications_users", "communications"
  add_foreign_key "communications_users", "users"
  add_foreign_key "groups_users", "groups"
  add_foreign_key "groups_users", "users"
  add_foreign_key "learning_experiences_groups", "groups"
  add_foreign_key "learning_experiences_groups", "learning_experiences"
  add_foreign_key "learning_experiences_licensed_contents", "learning_experiences"
  add_foreign_key "learning_experiences_licensed_contents", "licensed_contents"
  add_foreign_key "learning_experiences_users", "learning_experiences"
  add_foreign_key "learning_experiences_users", "users"
  add_foreign_key "licensed_contents", "contents"
  add_foreign_key "oauth_access_grants", "oauth_applications", column: "application_id"
  add_foreign_key "oauth_access_tokens", "oauth_applications", column: "application_id"
  add_foreign_key "oauth_openid_requests", "oauth_access_grants", column: "access_grant_id"
  add_foreign_key "permissions", "actions"
  add_foreign_key "permissions_roles", "permissions"
  add_foreign_key "permissions_roles", "roles"
  add_foreign_key "site_associations", "site_relationships"
  add_foreign_key "site_associations", "sites"
  add_foreign_key "site_associations", "sites", column: "related_site_id"
  add_foreign_key "sites_users", "sites"
  add_foreign_key "sites_users", "users"
  add_foreign_key "user_groups", "sites"
  add_foreign_key "users_roles", "roles"
  add_foreign_key "users_roles", "sites"
  add_foreign_key "users_roles", "users"
end
